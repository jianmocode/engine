(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var message = function () {
      function message() {
            _classCallCheck(this, message);
      }

      _createClass(message, null, [{
            key: "showMessage",
            value: function showMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在提示阶段禁用，防止多次点击
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "disabled";
                  }

                  //出现动画
                  _message.childNodes[1].style.transform = "translateY(16px)";
            }
      }, {
            key: "hideMessage",
            value: function hideMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在消失阶段启用，回复输入状态
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "";
                  }
                  //消失动画
                  _message.childNodes[1].style.transform = "translateY(-48px)";
            }
      }, {
            key: "clearMessage",
            value: function clearMessage() {
                  var _message = document.getElementById('message');

                  if (_message != null) {
                        _message.parentNode.removeChild(_message);
                  }
            }
      }, {
            key: "common",
            value: function common(color, shadow_color, title) {
                  var _this = this;

                  this.clearMessage();

                  var body = document.getElementsByTagName("body")[0];
                  var modal_style = "\n                  width:100vw;\n                  height:100vh;\n                  background-color:transparent;\n                  position:fixed;\n                  top:0;\n                  left:0;\n                  z-index:999999;\n                  display:flex;\n                  justify-content:center;\n            ";

                  var nodes_style = "\n                  \"height:48px;\n                  line-height:48px;\n                  padding:0 30px;\n                  background-color:" + color + ";\n                  box-shadow: 4px 4px 32px " + shadow_color + ";\n                  color:white;\n                  font-size:16px;\n                  letter-spacing:1px;\n                  border-radius:4px;\n                  transition:all ease 0.3s;\n                  transform:translateY(-36px);\"\n            ";

                  var nodes = document.createElement('div');
                  nodes.setAttribute("id", "message");
                  nodes.setAttribute("style", modal_style);

                  var nodes_main = "\n                  <span style=" + nodes_style + ">" + title + "</span>\n            ";
                  nodes.innerHTML = nodes_main;

                  body.appendChild(nodes);

                  setTimeout(function () {
                        _this.showMessage();
                  }, 0);

                  setTimeout(function () {
                        _this.hideMessage();
                  }, 1500);

                  setTimeout(function () {
                        _this.clearMessage();
                  }, 1800);
            }
      }, {
            key: "error",
            value: function error(title) {
                  this.common('#eb3939', 'rgba(235, 57, 57, 0.24)', title);
            }
      }, {
            key: "warn",
            value: function warn(title) {
                  this.common('#f1803f', 'rgba(241, 128, 63, 0.24)', title);
            }
      }, {
            key: "success",
            value: function success(title) {
                  this.common('#19b119', 'rgba(25, 177, 25, 0.24)', title);
            }
      }]);

      return message;
}();

module.exports = {
      message: message
};

},{}],2:[function(require,module,exports){
'use strict';

var _kit = require('../../../libs/assets/kit');

var web = getWeb();
Page({
      data: {},
      current_page: 1,
      has_load_all: false,
      onReady: function onReady(get) {
            var _that = this;

            _that.watchUserLogin();
            _that.handleClickLoadmore();
            _that.handleClickShowAndHideAnswerContent();
      },
      watchUserLogin: function watchUserLogin() {
            var _that = this;

            if (_that.data.user.user_id) {} else {
                  window.location.href = '/login';
            }
      },

      loadMoreAnswers: function loadMoreAnswers() {
            var _that = this;

            function updateAnswersItems(data) {
                  for (var i = 0; i < data.length; i++) {
                        var asset_path = '/static-file/default/desktop/assets';

                        var nodes = '\n                              <div\n                                    class="answer_item uk-flex uk-flex-column border_box"\n                              >\n                                    <a\n                                          class="question_title"\n                                          href="/qanda/detail/' + data[i].question_question_id + '"\n                                    >' + data[i].question_title + '</a>\n                                    <div class="answer_content">\n                                          <span class="summary answer_text">' + data[i].summary + '</span>\n                                          <span class="content answer_text none">' + data[i].content + '</span>\n                                          <button class="btn_show_all">\n                                                <span class="text">\u663E\u793A\u5168\u90E8</span>\n                                                <img\n                                                      class="icon_arrow_down"\n                                                      src="' + asset_path + '/images/icon_arrow_down.svg"\n                                                      alt="icon_arrow_down"\n                                                >\n                                          </button>\n                                    </div>\n                                    <div class="answer_options uk-flex uk-flex-between">\n                                          <span class="option_item">' + data[i].publish_time + '</span>\n                                          <button class="btn_collapse_answer uk-flex uk-flex-middle">\n                                                <span class="text">\u6536\u8D77</span>\n                                                <img\n                                                      class="img_collapse"\n                                                      src="' + asset_path + '/images/icon_arrow_up.png"\n                                                      alt="icon_collapse"\n                                                >\n                                          </button>\n                                    </div>\n                              </div>\n                        ';

                        $('.answer_items').append(nodes);
                  }
            }

            $.ajax({
                  type: "post",
                  url: "/_api/xpmsns/qanda/answer/search",
                  dataType: "json",
                  data: {
                        page: _that.current_page + 1,
                        perpage: "12",
                        user_id: _that.data.user.user_id,
                        "select": "question.question_id,question.title,user_id,summary,content,publish_time",
                        publish_desc: "1"
                  },
                  success: function success(response) {
                        if (response.data.length !== 0) {
                              updateAnswersItems(response.data);
                              _that.current_page = _that.current_page + 1;
                        } else {
                              _that.has_load_all = true;
                              _kit.message.warn('没有更多了');
                        }
                  },
                  error: function error(err) {
                        console.log(err);
                  }
            });
      },
      handleClickLoadmore: function handleClickLoadmore() {
            var _that = this;

            $('.btn_loadmore').on('click', function () {
                  if (!_that.has_load_all) {
                        _that.loadMoreAnswers();
                  }
            });
      },
      handleClickShowAndHideAnswerContent: function handleClickShowAndHideAnswerContent() {
            var _that = this;

            $('.answer_items').on('click', '.btn_show_all', function () {
                  $(this).hide();

                  $(this).parents('.answer_item').find('.btn_collapse_answer').show();

                  $(this).parents('.answer_item').find('.summary').hide();

                  $(this).parents('.answer_item').find('.content').show();
            });

            $('.answer_items').on('click', '.btn_collapse_answer', function () {
                  $(this).hide();

                  $(this).parents('.answer_item').find('.btn_show_all').show();

                  $(this).parents('.answer_item').find('.summary').show();

                  $(this).parents('.answer_item').find('.content').hide();
            });
      }
});

},{"../../../libs/assets/kit":1}]},{},[2]);
