(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var web = getWeb();
Page({
      data: {},
      loadSwiper: function loadSwiper() {
            var mySwiper = new Swiper('.swiper-container', {
                  direction: 'horizontal', // 垂直切换选项
                  loop: true, // 循环模式选项
                  autoplay: true,

                  // 如果需要分页器
                  pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                        renderBullet: function renderBullet(index, className) {
                              return '<span class="' + className + '">' + '</span>';
                        }
                  }
            });
      },

      onReady: function onReady() {
            var _that = this;

            _that.loadSwiper();
            _that.getGithubStar();
            _that.setSwiperHeight();
            _that.handleHoverUserCase();
      },
      getGithubStar: function getGithubStar() {
            $.ajax({
                  method: 'get',
                  url: 'https://api.github.com/repos/TarsCloud/Tars',
                  datatype: 'json',
                  success: function success(response) {
                        if (response.id) {
                              $('.github_star').text(response.stargazers_count);
                        } else {
                              UIkit.notification({
                                    message: '获取github star数量失败',
                                    status: 'danger',
                                    pos: 'bottom-right'
                              });
                        }
                  },
                  error: function error(err) {
                        console.log(err);
                  }
            });
      },
      setSwiperHeight: function setSwiperHeight() {
            var _el = $('.banner_wrap .swiper-wrapper');
            _el.height(_el.parents('.swiper-container').height());
      },
      handleHoverUserCase: function handleHoverUserCase() {
            $('.user_items .user_item').on('mouseenter', function () {
                  var user_story = $(this).find('.user_story').text();

                  if (user_story) {
                        $('.describtion .text').text(user_story);
                  } else {
                        UIkit.notification({
                              message: '用户故事未设置',
                              status: 'danger',
                              pos: 'bottom-right'
                        });
                  }
            });
      }
});

},{}]},{},[1]);
