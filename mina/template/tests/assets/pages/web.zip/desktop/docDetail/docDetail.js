(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var web = getWeb();
Page({
      data: {},
      current_title: '',
      current_content: '',
      current_children: [{
            name: '',
            path: ''
      }],
      generator: function generator(data) {
            var _loop = function _loop(i) {
                  var children_1 = '';

                  data[i].children.map(function (item_1) {
                        var child_1 = '';

                        if (item_1.hasOwnProperty('children')) {
                              var children_2 = '';

                              item_1.children.map(function (item_2) {
                                    var child_2 = '';

                                    if (item_2.hasOwnProperty('children')) {
                                          var children_3 = '';

                                          item_2.children.map(function (item_3) {
                                                var child_3 = '';

                                                if (item_3.hasOwnProperty('children')) {
                                                      var children_4 = '';

                                                      item_3.children.map(function (item_4) {
                                                            var child_4 = '';

                                                            if (item_4.hasOwnProperty('children')) {
                                                                  var children_5 = '';

                                                                  child_4 = '\n                                                                        <a \n                                                                              class="child" \n                                                                              data-path="' + item_4.path + '"\n                                                                        >' + item_4.name + '</a>\n                                                                        <div class="children none">' + children_5 + '</div>\n                                                                  ';

                                                                  children_4 = children_4 + child_4;
                                                            }
                                                      });

                                                      child_3 = '\n                                                            <a \n                                                                  class="child" \n                                                                  data-path="' + item_3.path + '"\n                                                            >' + item_3.name + '</a>\n                                                            <div class="children none">' + children_4 + '</div>\n                                                      ';

                                                      children_3 = children_3 + child_3;
                                                }
                                          });

                                          child_2 = '\n                                                <div class="item">\n                                                      <a \n                                                            class="child" \n                                                            data-path="' + item_2.path + '"\n                                                      >' + item_2.name + '</a>\n                                                      <div class="children none">' + children_3 + '</div>\n                                                </div>\n                                          ';
                                          children_2 = children_2 + child_2;
                                    }
                              });

                              child_1 = '\n                                    <div class="item">\n                                          <a \n                                                class="child" \n                                                data-path="' + item_1.path + '"\n                                          >' + item_1.name + '</a>\n                                          <div class="children none">' + children_2 + '</div>\n                                    </div>\n                              ';
                              children_1 = children_1 + child_1;
                        }
                  });

                  var root = '\n                        <div class="root">\n                              <a class="title">' + data[i].name + '</a>\n                              <div class="children_wrap">' + children_1 + '</div>\n                        </div>\n                  ';
                  $('#menu').append(root);
            };

            for (var i = 0; i < data.length; i++) {
                  _loop(i);
            }
      },

      onReady: function onReady() {
            var _that = this;

            _that.getPageData(_that.data.path);
            _that.generator(_that.data.catalog.summary);
            _that.handleClickChildren();
            _that.handleClickChild();
            _that.handleClickBtnSearch();
            _that.handleClickBtnMenu();
            _that.handleClickBtnBack();
      },
      setPageData: function setPageData(response) {
            var _that = this;

            _that.current_title = response.current.name;
            _that.current_content = response.content;
            _that.current_children = response.current.children;

            $('.publish_info .title').text(_that.current_title);
            $('.article').html(_that.current_content);

            if (_that.current_children.length) {
                  $('.content_children').show();
                  $('.child_items').html('');

                  _that.current_children.map(function (item) {
                        $('.child_items').append('\n                              <a class="child_item border_box" data-path="' + item.path + '">' + item.name + '</a>\n                        ');
                  });
            } else {
                  $('.content_children').hide();
            }
      },
      getPageData: function getPageData(path) {
            var _that = this;

            $.ajax({
                  type: "get",
                  url: "/_api//xpmsns/document/repo/getContent",
                  dataType: "json",
                  data: {
                        slug: "default",
                        path: path
                  },
                  success: function success(response) {
                        if (response.summary) {
                              _that.setPageData(response);
                        } else {
                              UIkit.notification({
                                    message: response.message,
                                    status: 'danger',
                                    pos: 'bottom-right'
                              });
                        }
                  },
                  error: function error(err) {
                        console.log(err);
                  }
            });
      },
      handleClickChildren: function handleClickChildren() {
            var _that = this;

            $(document).on('click', '#menu .item', function () {
                  if (_that.data.browser === 'mobile' || _that.data.browser === 'wxapp') {
                        $('.menu_wrap').css('transform', 'translateX(-300px)');
                  }
                  var _children = $(this).children('.children');

                  $('.children').addClass('none');
                  _children.removeClass('none');
            });
      },

      handleClickChild: function handleClickChild() {
            var _that = this;

            $(document).on('click', '#menu .child,.child_items .child_item', function () {
                  if (_that.data.browser === 'mobile' || _that.data.browser === 'wxapp') {
                        $('.menu_wrap').css('transform', 'translateX(-300px)');
                  }
                  _that.getPageData($(this).data('path'));

                  $('.child').removeClass('active');
                  $(this).addClass('active');
            });
      },
      handleClickBtnSearch: function handleClickBtnSearch() {
            var _that = this;

            function goSearch() {
                  window.open('/search/' + $('.input_search').val() + '/1');
            }

            function mobileGoSearch() {
                  window.open('/search/' + $('.search_input_search').val() + '/1');
            }

            $('.icon_search').on('click', function () {
                  if (_that.data.browser === 'desktop') {
                        goSearch();
                  } else {
                        $('.search_wrap').css('transform', 'translateX(0px)');
                  }
            });

            $('.input_search').on('keyup', function (e) {
                  if (e.keyCode === 13) {
                        goSearch();
                  }
            });

            $('.search_icon_search').on('click', function () {
                  mobileGoSearch();
            });

            $('.search_icon_search').on('keyup', function (e) {
                  if (e.keyCode === 13) {
                        mobileGoSearch();
                  }
            });
      },
      handleClickBtnMenu: function handleClickBtnMenu() {
            $('.icon_mobile_menu').on('click', function () {
                  $('.menu_wrap').css('transform', 'translateX(0px)');
            });
      },
      handleClickBtnBack: function handleClickBtnBack() {
            $('.btn_back').on('click', function () {
                  switch ($(this).data('type')) {
                        case 'menu':
                              $('.menu_wrap').css('transform', 'translateX(-300px)');
                              break;
                        case 'search':
                              $('.search_wrap').css('transform', 'translateX(80vw)');
                              break;
                  }
            });
      }
});

},{}]},{},[1]);
