(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var web = getWeb();
Page({
      data: {},
      current_page: 1,
      has_load_all: false,
      onReady: function onReady(get) {
            var _that = this;

            _that.hoverDocItem();
            _that.handleClickLoadmore();
            _that.handleClickBtnSearch();
      },
      hoverDocItem: function hoverDocItem() {
            $('.docs_item').hover(function () {
                  if ($(this).hasClass('docs_dev')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_dev_hover.png');
                  }

                  if ($(this).hasClass('docs_ops')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_ops_hover.png');
                  }

                  if ($(this).hasClass('docs_contribution')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_contribution_hover.png');
                  }
            }, function () {
                  if ($(this).hasClass('docs_dev')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_dev.png');
                  }

                  if ($(this).hasClass('docs_ops')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_ops.png');
                  }

                  if ($(this).hasClass('docs_contribution')) {
                        $(this).find('.img_signal').attr('src', '/static-file/default/desktop/assets/images/icon_contribution.png');
                  }
            });
      },
      loadMoreQuestions: function loadMoreQuestions() {
            var _that = this;

            function updateQuestionItems(data) {
                  for (var i = 0; i < data.length; i++) {
                        var user_nickname = data[i].user_nickname ? data[i].user_nickname : data[i].user_mobile;
                        var answer_cnt = data[i].answer_cnt ? data[i].answer_cnt : '0';
                        var tags = '';

                        if (data[i].tags) {
                              for (var j = 0; j < data[i].tags.length; j++) {
                                    var tag_nodes = '\n                                          <a\n                                                class="tags cursor_point"\n                                                href="/qanda/tag/' + data[i].tags[j] + '"\n                                          >' + data[i].tags[j] + '</a>\n                                    ';

                                    tags = tags + tag_nodes;
                              }
                        } else {
                              tags = '';
                        }

                        var nodes = '\n                              <div\n                                    class="question_item w_100 flex justify_between align_center"\n                              >\n                                    <div class="left">\n                                          <a\n                                                class="question box_vertical line_clamp_2 overflow_hidden color_333 fontsize_16 cursor_point"\n                                                href="/qanda/detail/' + data[i].question_id + '"\n                                          >' + data[i].title + '</a>\n                                          <div class="publish_info flex fontsize_12 mt_20">\n                                                <span class="publisher">' + user_nickname + '</span>\n                                                <span class="publish_time">' + data[i].publish_time + '</span>\n                                                <div class="tags_wrap">' + tags + '</div>\n                                          </div>\n                                    </div>\n                                    <div class="right flex">\n                                          <div class="option_item flex flex_column align_center justify_between">\n                                                <span class="value font_bold">' + answer_cnt + '</span>\n                                                <span class="name fontsize_14">\u56DE\u7B54</span>\n                                          </div>\n                                    </div>\n                              </div>\n                        ';

                        $('.question_items').append(nodes);
                  }
            }

            $.ajax({
                  type: "post",
                  url: "/_api/xpmsns/pages/recommend/getContents",
                  dataType: "json",
                  data: {
                        page: _that.current_page + 1,
                        perpage: "12",
                        slugs: "qanda_recommend",
                        select: "question_id,question.title,question.summary,question.content,question.answer_cnt,question.publish_time,user.nickname,user.mobile,category.name,tags,user.user_id"
                  },
                  success: function success(response) {
                        if (response.data.length !== 0) {
                              updateQuestionItems(response.data);
                              _that.current_page = _that.current_page + 1;
                        } else {
                              _that.has_load_all = true;

                              UIkit.notification({
                                    message: '没有更多了',
                                    status: 'danger',
                                    pos: 'bottom-right'
                              });
                        }
                  },
                  error: function error(err) {
                        console.log(err);
                  }
            });
      },
      handleClickLoadmore: function handleClickLoadmore() {
            var _that = this;

            $('.btn_showmore').on('click', function () {
                  if (!_that.has_load_all) {
                        _that.loadMoreQuestions();
                  }
            });
      },
      handleClickBtnSearch: function handleClickBtnSearch() {
            function goSearch() {
                  window.open('/search/' + $('.input_search').val() + '/1');
            }

            $('.btn_search').on('click', function () {
                  goSearch();
            });

            $('.input_search').on('keyup', function (e) {
                  if (e.keyCode === 13) {
                        goSearch();
                  }
            });
      }
});

},{}]},{},[1]);
