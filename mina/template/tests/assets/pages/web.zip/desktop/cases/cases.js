(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var web = getWeb();
Page({
      data: {},
      onReady: function onReady() {
            var _that = this;

            _that.setLogo();
            _that.setAvatar();
      },
      setLogo: function setLogo() {
            $('.header_wrap').find('.logo').attr('src', "/static-file/default/desktop/assets/images/logo_white.png");
      },
      setAvatar: function setAvatar() {
            $('.person_entry').css({
                  'background': 'url(/static-file/default/desktop/assets/images/avatar_white.png) no-repeat 20px center'
            });
      }
});

},{}]},{},[1]);
