(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var message = function () {
      function message() {
            _classCallCheck(this, message);
      }

      _createClass(message, null, [{
            key: "showMessage",
            value: function showMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在提示阶段禁用，防止多次点击
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "disabled";
                  }

                  //出现动画
                  _message.childNodes[1].style.transform = "translateY(16px)";
            }
      }, {
            key: "hideMessage",
            value: function hideMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在消失阶段启用，回复输入状态
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "";
                  }
                  //消失动画
                  _message.childNodes[1].style.transform = "translateY(-48px)";
            }
      }, {
            key: "clearMessage",
            value: function clearMessage() {
                  var _message = document.getElementById('message');

                  if (_message != null) {
                        _message.parentNode.removeChild(_message);
                  }
            }
      }, {
            key: "common",
            value: function common(color, shadow_color, title) {
                  var _this = this;

                  this.clearMessage();

                  var body = document.getElementsByTagName("body")[0];
                  var modal_style = "\n                  width:100vw;\n                  height:100vh;\n                  background-color:transparent;\n                  position:fixed;\n                  top:0;\n                  left:0;\n                  z-index:999999;\n                  display:flex;\n                  justify-content:center;\n            ";

                  var nodes_style = "\n                  \"height:48px;\n                  line-height:48px;\n                  padding:0 30px;\n                  background-color:" + color + ";\n                  box-shadow: 4px 4px 32px " + shadow_color + ";\n                  color:white;\n                  font-size:16px;\n                  letter-spacing:1px;\n                  border-radius:4px;\n                  transition:all ease 0.3s;\n                  transform:translateY(-36px);\"\n            ";

                  var nodes = document.createElement('div');
                  nodes.setAttribute("id", "message");
                  nodes.setAttribute("style", modal_style);

                  var nodes_main = "\n                  <span style=" + nodes_style + ">" + title + "</span>\n            ";
                  nodes.innerHTML = nodes_main;

                  body.appendChild(nodes);

                  setTimeout(function () {
                        _this.showMessage();
                  }, 0);

                  setTimeout(function () {
                        _this.hideMessage();
                  }, 1500);

                  setTimeout(function () {
                        _this.clearMessage();
                  }, 1800);
            }
      }, {
            key: "error",
            value: function error(title) {
                  this.common('#eb3939', 'rgba(235, 57, 57, 0.24)', title);
            }
      }, {
            key: "warn",
            value: function warn(title) {
                  this.common('#f1803f', 'rgba(241, 128, 63, 0.24)', title);
            }
      }, {
            key: "success",
            value: function success(title) {
                  this.common('#19b119', 'rgba(25, 177, 25, 0.24)', title);
            }
      }]);

      return message;
}();

module.exports = {
      message: message
};

},{}],2:[function(require,module,exports){
"use strict";

function setCookie(cookie_name, value, expiredays) {
      var exdate = new Date();

      exdate.setDate(exdate.getDate() + expiredays);

      document.cookie = cookie_name + "=" + escape(value) + (expiredays == null ? "" : ";expires=" + exdate.toGMTString()) + ";path=/";
}

function getCookie(cookie_name) {
      if (document.cookie.length > 0) {
            var cookie_start = document.cookie.indexOf(cookie_name + "=");
            if (cookie_start != -1) {
                  cookie_start = cookie_start + cookie_name.length + 1;
                  var cookie_end = document.cookie.indexOf(";", cookie_start);

                  if (cookie_end == -1) {
                        cookie_end = document.cookie.length;
                  }
                  return unescape(document.cookie.substring(cookie_start, cookie_end));
            }
      }
      return "";
}

module.exports = {
      setCookie: setCookie,
      getCookie: getCookie
};

},{}],3:[function(require,module,exports){
'use strict';

var _kit = require('../../../libs/assets/kit');

var _utils = require('../../../libs/assets/utils');

var web = getWeb();
Page({
      data: {},
      onReady: function onReady(get) {
            var _that = this;

            console.log((0, _utils.getCookie)('client_token'));

            _that.handleClickLogin();
            _that.getVcode();
      },
      getVcode: function getVcode() {
            //载入图形验证码
            $('.btn_qr_code').on('click', function () {
                  $(this).find('.img_qr_code').attr('src', '/_api/xpmsns/user/user/vcode?width=150&height=40&size=20&' + Date.parse(new Date()));
            });
      },
      handleClickLogin: function handleClickLogin() {
            $('.btn_login').on('click', function () {
                  $.ajax({
                        type: "post",
                        url: "/_api/xpmsns/user/user/login",
                        dataType: "json",
                        data: $('#login_form').serialize(),
                        success: function success(response) {
                              if (response.user_id) {
                                    _kit.message.success('登录成功');
                                    (0, _utils.setCookie)('__client_token', response.client_token, 2);

                                    setTimeout(function () {
                                          window.location.href = '/profile/project/1';
                                    }, 800);
                              } else {
                                    _kit.message.error(response.message);
                              }
                        },
                        error: function error(err) {
                              _kit.message.error(err.message);
                        }
                  });
            });
      }
});

},{"../../../libs/assets/kit":1,"../../../libs/assets/utils":2}]},{},[3]);
