(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var message = function () {
      function message() {
            _classCallCheck(this, message);
      }

      _createClass(message, null, [{
            key: "showMessage",
            value: function showMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在提示阶段禁用，防止多次点击
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "disabled";
                  }

                  //出现动画
                  _message.childNodes[1].style.transform = "translateY(16px)";
            }
      }, {
            key: "hideMessage",
            value: function hideMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在消失阶段启用，回复输入状态
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "";
                  }
                  //消失动画
                  _message.childNodes[1].style.transform = "translateY(-48px)";
            }
      }, {
            key: "clearMessage",
            value: function clearMessage() {
                  var _message = document.getElementById('message');

                  if (_message != null) {
                        _message.parentNode.removeChild(_message);
                  }
            }
      }, {
            key: "common",
            value: function common(color, shadow_color, title) {
                  var _this = this;

                  this.clearMessage();

                  var body = document.getElementsByTagName("body")[0];
                  var modal_style = "\n                  width:100vw;\n                  height:100vh;\n                  background-color:transparent;\n                  position:fixed;\n                  top:0;\n                  left:0;\n                  z-index:999999;\n                  display:flex;\n                  justify-content:center;\n            ";

                  var nodes_style = "\n                  \"height:48px;\n                  line-height:48px;\n                  padding:0 30px;\n                  background-color:" + color + ";\n                  box-shadow: 4px 4px 32px " + shadow_color + ";\n                  color:white;\n                  font-size:16px;\n                  letter-spacing:1px;\n                  border-radius:4px;\n                  transition:all ease 0.3s;\n                  transform:translateY(-36px);\"\n            ";

                  var nodes = document.createElement('div');
                  nodes.setAttribute("id", "message");
                  nodes.setAttribute("style", modal_style);

                  var nodes_main = "\n                  <span style=" + nodes_style + ">" + title + "</span>\n            ";
                  nodes.innerHTML = nodes_main;

                  body.appendChild(nodes);

                  setTimeout(function () {
                        _this.showMessage();
                  }, 0);

                  setTimeout(function () {
                        _this.hideMessage();
                  }, 1500);

                  setTimeout(function () {
                        _this.clearMessage();
                  }, 1800);
            }
      }, {
            key: "error",
            value: function error(title) {
                  this.common('#eb3939', 'rgba(235, 57, 57, 0.24)', title);
            }
      }, {
            key: "warn",
            value: function warn(title) {
                  this.common('#f1803f', 'rgba(241, 128, 63, 0.24)', title);
            }
      }, {
            key: "success",
            value: function success(title) {
                  this.common('#19b119', 'rgba(25, 177, 25, 0.24)', title);
            }
      }]);

      return message;
}();

module.exports = {
      message: message
};

},{}],2:[function(require,module,exports){
'use strict';

var _kit = require('../../../libs/assets/kit');

var web = getWeb();
var hasAgreed = false;

Page({
      data: {},
      onReady: function onReady(get) {
            var _that = this;

            _that.validateIsEmpty();
            _that.getVcode();
            _that.getSMSCode();
            _that.handleClickAgree();
            _that.handleClickSignup(_that.data.type);
      },
      validateIsEmpty: function validateIsEmpty() {
            var regular_email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/;
            var regular_mobile = /^1[0-9]{10}$/;

            var isFocused = false;

            $('.input').on('focus', function () {
                  isFocused = true;
            });

            $('.input').on('blur', function () {
                  if (isFocused) {
                        if ($(this).val() === '') {
                              _kit.message.warn('输入不能为空');
                        } else {
                              if ($(this).hasClass('email')) {
                                    if (!regular_email.test($(this).val())) {
                                          _kit.message.warn('邮箱格式输入错误');
                                    }
                              }
                              if ($(this).hasClass('mobile')) {
                                    if (!regular_mobile.test($(this).val())) {
                                          _kit.message.warn('请输入正确的手机号码');
                                    }
                              }
                              if ($(this).hasClass('confirm_password')) {
                                    if ($(this).val() !== $('.password').val()) {
                                          _kit.message.warn('两次输入的密码不一致');
                                    }
                              }
                        }
                        isFocused = false;
                  }
            });
      },
      getVcode: function getVcode() {
            //载入图形验证码
            $('.btn_qr_code').on('click', function () {
                  $(this).find('.img_qr_code').attr('src', '/_api/xpmsns/user/user/vcode?width=150&height=40&size=20&' + Date.parse(new Date()));
            });
      },
      getSMSCode: function getSMSCode() {
            var _that = this;
            // 获取手机验证码
            $('.btn_get_message').on('click', function () {
                  $.ajax({
                        type: "get",
                        url: "/_api/xpmsns/user/user/getSMSCode",
                        dataType: "text",
                        data: {
                              _vcode: $('.verify_code').val(),
                              mobile: $('.mobile').val()
                        },
                        success: function success(response) {
                              var json_data = JSON.parse(response);

                              if (json_data.code === 0) {
                                    _kit.message.success(json_data.message);
                                    _that.message_clock();
                              } else {
                                    _kit.message.error(json_data.message);
                              }
                        },
                        error: function error(err) {
                              _kit.message.error(err);
                        }
                  });
            });
      },
      message_clock: function message_clock() {
            var _el = $('.btn_get_message');
            _el.attr('disabled', 'true');
            var _timer = 60;
            var _clock = setInterval(function () {
                  _el.html(_timer + 's');
                  if (_timer === 0) {
                        clearInterval(_clock);
                        _el.removeAttr('disabled');
                        _el.html('发送短信验证');
                  }
                  _timer = _timer - 1;
            }, 1000);
      },
      handleClickAgree: function handleClickAgree() {
            $('.btn_agree').on('click', function () {
                  var _el = $(this).find('.inner');

                  if (_el.hasClass('none')) {
                        _el.removeClass('none');
                        hasAgreed = true;
                  } else {
                        _el.addClass('none');
                        hasAgreed = false;
                  }
            });
      },
      handleClickSignup: function handleClickSignup(type) {
            var validate_input = false;

            function submitForm() {
                  $.ajax({
                        type: "post",
                        url: "/_api/xpmsns/user/user/create",
                        dataType: "json",
                        data: $('#signup_form').serialize(),
                        success: function success(response) {
                              if (response.code === 0) {
                                    _kit.message.success(response.message);
                                    window.location.href = "/signupSuccess";
                              } else {
                                    _kit.message.error(response.message);
                              }
                        },
                        error: function error(err) {
                              _kit.message.error(err.message);
                        }
                  });
            }

            $('.btn_signup').on('click', function () {
                  console.log($('#signup_form').serialize());

                  if (type === 'person') {
                        validate_input = $('.user_name').val() && $('.name').val() && $('.password').val() && $('.confirm_password').val() && $('.email').val() && $('.mobile').val() && $('.message_code').val() && hasAgreed;
                  } else {
                        validate_input = $('.user_name').val() && $('.name').val() && $('.company').val() && $('.password').val() && $('.confirm_password').val() && $('.charge_name').val() && $('.charge_title').val() && $('.email').val() && $('.mobile').val() && $('.message_code').val() && hasAgreed;
                  }

                  if (validate_input) {
                        submitForm();
                  } else {
                        _kit.message.warn('注册失败，请检查表单输入项是否完整且确认接受用户协议');
                  }
            });
      }
});

},{"../../../libs/assets/kit":1}]},{},[2]);
