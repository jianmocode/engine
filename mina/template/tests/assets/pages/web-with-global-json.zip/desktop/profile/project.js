(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var message = function () {
      function message() {
            _classCallCheck(this, message);
      }

      _createClass(message, null, [{
            key: "showMessage",
            value: function showMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在提示阶段禁用，防止多次点击
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "disabled";
                  }

                  //出现动画
                  _message.childNodes[1].style.transform = "translateY(16px)";
            }
      }, {
            key: "hideMessage",
            value: function hideMessage() {
                  var _message = document.getElementById("message");
                  var _input = document.getElementsByTagName("input");

                  //将input在消失阶段启用，回复输入状态
                  for (var i = 0; i < _input.length; i++) {
                        _input[i].disabled = "";
                  }
                  //消失动画
                  _message.childNodes[1].style.transform = "translateY(-48px)";
            }
      }, {
            key: "clearMessage",
            value: function clearMessage() {
                  var _message = document.getElementById('message');

                  if (_message != null) {
                        _message.parentNode.removeChild(_message);
                  }
            }
      }, {
            key: "common",
            value: function common(color, shadow_color, title) {
                  var _this = this;

                  this.clearMessage();

                  var body = document.getElementsByTagName("body")[0];
                  var modal_style = "\n                  width:100vw;\n                  height:100vh;\n                  background-color:transparent;\n                  position:fixed;\n                  top:0;\n                  left:0;\n                  z-index:999999;\n                  display:flex;\n                  justify-content:center;\n            ";

                  var nodes_style = "\n                  \"height:48px;\n                  line-height:48px;\n                  padding:0 30px;\n                  background-color:" + color + ";\n                  box-shadow: 4px 4px 32px " + shadow_color + ";\n                  color:white;\n                  font-size:16px;\n                  letter-spacing:1px;\n                  border-radius:4px;\n                  transition:all ease 0.3s;\n                  transform:translateY(-36px);\"\n            ";

                  var nodes = document.createElement('div');
                  nodes.setAttribute("id", "message");
                  nodes.setAttribute("style", modal_style);

                  var nodes_main = "\n                  <span style=" + nodes_style + ">" + title + "</span>\n            ";
                  nodes.innerHTML = nodes_main;

                  body.appendChild(nodes);

                  setTimeout(function () {
                        _this.showMessage();
                  }, 0);

                  setTimeout(function () {
                        _this.hideMessage();
                  }, 1500);

                  setTimeout(function () {
                        _this.clearMessage();
                  }, 1800);
            }
      }, {
            key: "error",
            value: function error(title) {
                  this.common('#eb3939', 'rgba(235, 57, 57, 0.24)', title);
            }
      }, {
            key: "warn",
            value: function warn(title) {
                  this.common('#f1803f', 'rgba(241, 128, 63, 0.24)', title);
            }
      }, {
            key: "success",
            value: function success(title) {
                  this.common('#19b119', 'rgba(25, 177, 25, 0.24)', title);
            }
      }]);

      return message;
}();

module.exports = {
      message: message
};

},{}],2:[function(require,module,exports){
'use strict';

var _kit = require('../../../libs/assets/kit');

var web = getWeb();
Page({
      data: {},
      onReady: function onReady(get) {
            var _that = this;

            _that.watchUserLogin();
            _that.handleClickBtnMore();
            _that.handleClickBtnNew();
            _that.handleClickBtnCancel();
            _that.submitNewProjectForm();
            _that.handleClickBtnOption();
      },
      watchUserLogin: function watchUserLogin() {
            var _that = this;

            if (_that.data.user.user_id) {} else {
                  window.location.href = '/login';
            }
      },
      handleClickBtnMore: function handleClickBtnMore() {
            $('.btn_more').on('click', function () {
                  $('.option_items').hide();

                  $(this).parents('.options').find('.option_items').fadeIn().css('display', 'flex');
            });

            $('body').on('click', function (e) {
                  var target = $(e.target);

                  if (!target.is('.option_items') && !target.is('.btn_option') && !target.is('.btn_more')) {
                        $('.option_items').fadeOut();
                  }
            });
      },

      handleClickBtnNew: function handleClickBtnNew() {
            $('.btn_new').on('click', function () {
                  $('.new_project_wrap').fadeIn().css('display', 'flex');
            });
      },
      handleClickBtnCancel: function handleClickBtnCancel() {
            $('.btn_cancel').on('click', function () {
                  $('.new_project_wrap').fadeOut();
            });
      },
      submitNewProjectForm: function submitNewProjectForm() {
            $('.btn_confirm').on('click', function () {
                  if ($('.input_name').val() && $('.input_remark').val()) {
                        $.ajax({
                              type: "post",
                              url: "/_api/xpmsns/container/instance/create",
                              dataType: "json",
                              data: $('#new_project_form').serialize(),
                              success: function success(response) {
                                    if (response.job_id) {
                                          setTimeout(function () {
                                                window.location.reload();
                                          }, 300);
                                    } else {
                                          UIkit.notification({
                                                message: response.message,
                                                status: 'danger',
                                                pos: 'bottom-right'
                                          });
                                    }
                              },
                              error: function error(err) {
                                    console.log(err);
                              }
                        });
                  } else {
                        UIkit.notification({
                              message: '请输入项目名称和备注',
                              status: 'danger',
                              pos: 'bottom-right'
                        });
                  }
            });
      },
      handleClickBtnOption: function handleClickBtnOption() {
            function operateInstance(id, method) {
                  $.ajax({
                        type: "post",
                        url: '/_api/xpmsns/container/instance/manage?instance_id=' + id + '&method=' + method,
                        dataType: "json",
                        data: {},
                        success: function success(response) {
                              if (response.job_id) {
                                    setTimeout(function () {
                                          window.location.reload();
                                    }, 300);
                              } else {
                                    UIkit.notification({
                                          message: response.message,
                                          status: 'danger',
                                          pos: 'bottom-right'
                                    });
                              }
                        },
                        error: function error(err) {
                              console.log(err);
                        }
                  });
            }

            $('.btn_option').on('click', function () {
                  switch ($(this).data('type')) {
                        case 'visit':
                              break;
                        case 'start':
                              operateInstance($(this).data('id'), 'start');
                              break;
                        case 'stop':
                              operateInstance($(this).data('id'), 'stop');
                              break;
                        case 'restart':
                              operateInstance($(this).data('id'), 'restart');
                              break;
                        case 'reset':
                              operateInstance($(this).data('id'), 'reset');
                              break;
                        case 'del':
                              operateInstance($(this).data('id'), 'remove');
                              break;
                  }
            });
      }
});

},{"../../../libs/assets/kit":1}]},{},[2]);
