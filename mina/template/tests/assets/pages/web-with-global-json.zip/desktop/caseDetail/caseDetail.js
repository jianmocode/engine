(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var web = getWeb();
Page({
      data: {},
      onReady: function onReady(get) {
            var _that = this;

            _that.setLogo();
            _that.setAvatar();
            _that.animateHeader();
            _that.replaceSlot();
      },
      setLogo: function setLogo() {
            $('.header_wrap').find('.logo').attr('src', "/static-file/default/desktop/assets/images/logo_white.png");
      },
      setAvatar: function setAvatar() {
            $('.person_entry').css({
                  'background': 'url(/static-file/default/desktop/assets/images/avatar_white.png) no-repeat 20px center'
            });
      },

      animateHeader: function animateHeader() {
            function changeHeader() {
                  var _el = $('.header_wrap');

                  _el.removeClass('header_wrap_top').addClass('header_wrap_untop');

                  _el.find('.logo').attr('src', "/static-file/default/desktop/assets/images/logo.png");

                  $('.person_entry').css({
                        'background': 'url(/static-file/default/desktop/assets/images/avatar.png) no-repeat 20px center',
                        'color': '#0253d8'
                  });
            }

            function resetHeader() {
                  var _el = $('.header_wrap');

                  _el.removeClass('header_wrap_untop').addClass('header_wrap_top');

                  _el.find('.logo').attr('src', "/static-file/default/desktop/assets/images/logo_white.png");

                  $('.person_entry').css({
                        'background': 'url(/static-file/default/desktop/assets/images/avatar_white.png) no-repeat 20px center',
                        'color': 'white'
                  });
            }

            $(window).scroll(function () {
                  if ($(window).scrollTop() > 300) {
                        changeHeader();
                  } else {
                        resetHeader();
                  }
            });
      },
      repositionSlot: function repositionSlot() {
            if (this.data.browser == 'desktop') {
                  var offset = ($('body').width() - 1200) / 2;
                  $('.words_wrap').css('margin-left', -offset);
            } else {
                  $('.words_wrap .img_bg').css('height', $('.words_wrap').height());
            }
      },
      replaceSlot: function replaceSlot() {
            var _that = this;

            var html = $('.article').html();
            var data = this.data.case.stories;

            for (var i = 0; i < data.length; i++) {
                  var nodes = '\n                        <section class="words_wrap w_100 flex justify_center relative none">\n                              <img\n                                    class="img_bg absolute w_100 h_100"\n                                    src="' + data[i].url + '"\n                                    alt="img_bg"\n                              >\n                              <div class="words white flex flex_column align_center">\n                                    <div class="words_content fontsize_20 text_center">' + data[i].title + '</div>\n                                    <span class="words_person fontsize_14">' + data[i].summary + '</span>\n                              </div>\n                        </section>\n                  ';

                  html = html.replace('#{{USER_STORY_' + (i + 1) + '}}', nodes);
                  $('.article').html(html);
            }

            $('.words_wrap').removeClass('none');
            _that.repositionSlot();
      }
});

},{}]},{},[1]);
