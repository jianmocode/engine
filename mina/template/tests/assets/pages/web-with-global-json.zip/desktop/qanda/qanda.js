(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.$$ = exports.ComponentUtil = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _image = require('../web/components/uploader/image');

var _image2 = _interopRequireDefault(_image);

var _image3 = require('../web/components/editor/image');

var _image4 = _interopRequireDefault(_image3);

var _html = require('../web/components/editor/html');

var _html2 = _interopRequireDefault(_html);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 简墨组件管理器
 */
var componentRoot = '../web/components/';


var components = {
	"uploader/image": _image2.default,
	"editor/image": _image4.default,
	"editor/html": _html2.default
};

var ComponentUtil = function () {
	function ComponentUtil(selector) {
		var option = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
		var component = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

		_classCallCheck(this, ComponentUtil);

		this.selector = selector;
		this.component = component;
		this.option = option;

		// 初始化
		if (component != null) {
			this.load(option);
			return this.component;
		}
	}

	_createClass(ComponentUtil, [{
		key: 'load',
		value: function load(option) {
			option["__component"] = true;
			option['selector'] = this.selector;
			try {
				this.component.$load(option);
			} catch (e) {
				console.log('Load Component Error', this.component, e);
			}

			$(option['selector']).data('_component', this.component.options);
		}
	}, {
		key: 'setOption',
		value: function setOption(option) {
			this.option = option;
		}
	}]);

	return ComponentUtil;
}();

function getComponent(selector) {

	if ($(selector).data('_component')) {
		$(selector).data('_component').selector = selector;
		return $(selector).data('_component');
	}

	return new ComponentUtil(selector);
}

var $$ = getComponent;

// 用于动态扩展 Component
var $com = new ComponentUtil({});

/**
 * 加载组件
 * @return {[type]} [description]
 */
$$.import = function () {
	var _arguments = arguments;


	for (var i in arguments) {

		if (!components[arguments[i]]) {
			console.log(arguments[i], ' not found. ');
			continue;
		}
		try {
			(function () {
				// 添加组件名称方法
				var path = _arguments[i];
				var name = components[path].options._name;
				if (name) {
					$com.__proto__[name] = function (option) {
						return new ComponentUtil(this.selector, option, components[path]);
					};
				}
			})();
		} catch (e) {
			console.log(arguments[i], ' import error. ', e);
		}
	}
};

exports.ComponentUtil = ComponentUtil;
exports.$$ = $$;

},{"../web/components/editor/html":2,"../web/components/editor/image":3,"../web/components/uploader/image":4}],2:[function(require,module,exports){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var com = Page({
    _name: 'HtmlEditor',
    data: {},
    template: '<textarea>HTML文本编辑器</textarea>',
    events: {},
    props: {
        "disabled": "bool", // 是否 disabled
        "autofocus": "bool", // 是否 自动聚焦
        "fetch-image": "bool", // 是否抓取图片地址
        "name": "string", // 名称
        "lang": 'string', // 语言
        "id": "string", // ID
        "url": "string", // 云端通信地址
        "validate": "string", // 数据验证
        "placeholder": "string", // placeholder
        "tooltip": "function", // 工具
        "toolbar-sticky": "object", // 工具栏是否置顶 ( "top:xx" ) 
        "maxChunkSize": "number", // 切片大小
        "onUploadSuccess": "function", // 文件上传成功回调
        "onUploadFailure": "function" // 文件上传失败回调
    },

    // 组件初始化
    onReady: function onReady(params) {
        var _this = this;

        // XMLHttpRequest sendAsBinary
        if (!XMLHttpRequest.prototype.sendAsBinary) {
            XMLHttpRequest.prototype.sendAsBinary = function (sData) {
                var nBytes = sData.length,
                    ui8Data = new Uint8Array(nBytes);
                for (var nIdx = 0; nIdx < nBytes; nIdx++) {
                    ui8Data[nIdx] = sData.charCodeAt(nIdx) & 0xff;
                }
                this.send(ui8Data);
            };
        }

        // Default Setting 
        Trix.config.blockAttributes.default.tagName = "p";
        Trix.config.blockAttributes.default.breakOnReturn = true;

        // + color 调色板属性
        Trix.config.textAttributes.color = {
            styleProperty: "color",
            inheritable: true,
            parser: function parser(element) {
                if (element.style.color != "" && element.style.color.trim() != "") {
                    return element.style.color.trim();
                }
                return false;
            }

            // + Heading 
        };var headings = [{ name: "heading-1", tagName: 'h1', title: "一级标题" }, { name: "heading-2", tagName: 'h2', title: "二级标题" }, { name: "heading-3", tagName: 'h3', title: "三级标题" }, { name: "heading-4", tagName: 'h4', title: "四级标题" }, { name: "heading-5", tagName: 'h5', title: "五级标题" }];

        var _loop = function _loop() {
            var h = headings[i];
            Trix.config.textAttributes[h.name] = {
                tagName: h.tagName,
                inheritable: false,
                parser: function parser(element) {
                    element.tagName !== h.tagName;
                }

                // Trix.config.blockAttributes[h.name] = {
                //     tagName: h.tagName,
                //     terminal: true,
                //     breakOnReturn: true,
                //     group: false
                // }
            };
        };

        for (var i in headings) {
            _loop();
        }

        // + alignments
        var alignments = [{ name: "align-left", value: "left", title: "左对齐" }, { name: "align-center", value: "center", title: "居中对齐" }, { name: "align-right", value: "right", title: "右对齐" }, { name: "align-justify", value: "justify", title: "两端对齐" }];
        for (var i in alignments) {
            var ali = alignments[i];
            Trix.config.blockAttributes[ali.name] = {
                tagName: 'p-' + ali.name,
                breakOnReturn: true,
                group: false
            };
        }

        // + divider
        Trix.config.blockAttributes.divider = {
            tagName: 'hr',
            breakOnReturn: true,
            terminal: true,
            group: false
        };

        var $elms = $(params['selector']);
        this.template = $('component[name=editor-html]').html().toString();
        this.events.change = typeof params['change'] == 'function' ? params['change'] : function () {};
        this.events.error = typeof params['error'] == 'function' ? params['error'] : function () {};
        this.events.success = typeof params['success'] == 'function' ? params['success'] : function () {};
        $elms.each(function (idx, elm) {
            _this.init($(elm));
        });

        // 添加 图片、视频和附件按钮
        // @see https://gist.github.com/pmhoudry/a0dc6905872a41a316135d42a5537ddb
        addEventListener("trix-initialize", function (event) {

            // 文字对齐面板
            _this.addNewBlock(event.target, "alignment");
            _this.addAlignments(event.target);

            // 文字属性面板
            _this.addNewBlock(event.target, "text");
            _this.addColor(event.target); // 添加颜色
            _this.addHeading(event.target); // 标题管理
            _this.addDivider(event.target); // 分割线

            // 附件上传面板
            _this.addNewBlock(event.target, "custom"); // 添加个性化面板
            _this.addAttach(event.target); // 添加附件
            // this.addImage( event.target ); // 添加图片
            // this.addVideo( event.target ); // 添加视频
        });
    },

    // 初始化
    init: function init($elm) {
        var _this2 = this;

        var attrs = this.getAttrs($elm);
        attrs["lang"] = attrs["lang"] ? attrs["lang"] : 'zh-CN';
        attrs["url"] = attrs["url"] ? attrs["url"] : '';

        var value = $elm.html();
        var data = Object.assign({}, attrs);
        data["value"] = value;

        var html = Mustache.render(this.template, data);
        $elm.html(html);
        $elm.addClass('editor-inited'); //标记初始化完毕

        // Init trix
        $('.jm-editor-html', $elm).append('\n            <trix-editor \n                placeholder=' + attrs.placeholder + '\n                class="jm-article" \n                ' + (attrs.autofocus ? "autofocus=true" : "") + '\n                input="' + attrs.name + '_input">\n            </trix-editor>');

        var elm = $('.jm-editor-html', $elm).get(0);
        if (elm) {

            // 处理文件上传
            elm.addEventListener("trix-attachment-add", function (event) {
                _this2.bindFileUploadHandler(event.target, event.attachment, attrs);
            });

            // 工具栏置顶
            if (attrs["toolbar-sticky"]) {
                this.toolbarSticky(elm.querySelector("trix-editor"), attrs["toolbar-sticky"]);
            }
        }
    },

    // 工具栏置顶
    toolbarSticky: function toolbarSticky(trix, option) {

        option["top"] = parseInt(option["top"]) || 0;
        var rect = trix.toolbarElement.getBoundingClientRect();
        var top = rect.top || 0;
        var style = getComputedStyle(trix.toolbarElement);
        var editorStyle = getComputedStyle(trix.editor.element);
        var width = style.width || "100%";
        var paddingTop = parseInt(editorStyle.paddingTop);
        var height = parseInt(style.height) || "auto";

        if (top < 0) {
            top = 0;
        }

        var getScroll = function getScroll() {
            if (window.pageYOffset != undefined) {
                return [pageXOffset, pageYOffset];
            } else {
                var sx,
                    sy,
                    d = document,
                    r = d.documentElement,
                    b = d.body;
                sx = r.scrollLeft || b.scrollLeft || 0;
                sy = r.scrollTop || b.scrollTop || 0;
                return [sx, sy];
            }
        };

        var setPos = function setPos() {
            var p = getScroll();
            var offset = top - p[1];
            if (option["top"] > offset) {
                trix.toolbarElement.style.top = option["top"] + 'px';
                trix.toolbarElement.style.width = width;
                trix.toolbarElement.style.position = "fixed";
                trix.toolbarElement.style.zIndex = 960;
                trix.editor.element.style.paddingTop = height + paddingTop + 'px';
            } else {
                trix.toolbarElement.style.position = "static";
                trix.editor.element.style.paddingTop = paddingTop + 'px';
            }

            // console.log( option["top"] , ">", offset, top , "-", p[1] );
        };

        // 设定当前进度条
        setPos();

        // 监听滚动事件
        window.addEventListener('scroll', function (event) {
            setPos();
        });
    },


    // 处理文件上传
    bindFileUploadHandler: function bindFileUploadHandler(trix, attachment, attrs) {
        var url = attrs["url"] || "";
        if (url == null || url == "") {
            console.log('未指定文件上传云端服务地址(上传文件功能将无法使用)', " trix-id=", trix.getAttribute("trix-id"), attachment);
            return;
        }

        // 上传文件
        uploadAttachment(function (progress) {
            attachment.setUploadProgress(progress);
        }, attrs.onUploadSuccess, attrs.onUploadFailure);

        /**
         * 上传文件 ( 下一版应该支持分段上传 )
         */
        function uploadAttachment(progressCallback, successCallback, failureCallback) {

            progressCallback = progressCallback || function () {};
            successCallback = successCallback || function () {};
            failureCallback = failureCallback || function () {};

            // 复制过图片等
            if (!attachment.file) {
                fetchUrl(progressCallback, successCallback, failureCallback);
                return;
            }

            sendFile(progressCallback, successCallback, failureCallback);
        }

        /**
         * 分段上传文件
         * @param {*} progressCallback 
         * @param {*} successCallback 
         * @param {*} failureCallback 
         */
        function sendFile(progressCallback, successCallback, failureCallback) {

            var file = attachment.file;

            // 校验文件

            var name = file.name;
            var total = file.size;
            var maxChunkSize = (attrs.maxChunkSize ? attrs.maxChunkSize : 512) * 1024; // 默认 512k
            var chunkCount = Math.ceil(total / maxChunkSize);

            function sendRequest(next) {

                // 所有请求完成
                if (next >= chunkCount) {
                    return;
                }

                var start = next * maxChunkSize;
                var end = start + maxChunkSize;
                if (end > total) {
                    end = total;
                }

                // Send Remote 
                var xhr = new XMLHttpRequest();

                xhr.upload.addEventListener("progress", function (event) {
                    var progress = start / total * 100;
                    var progressMax = (start + maxChunkSize) / total * 100;
                    var p = progressMax - progress;
                    var chunckProgress = event.loaded / event.total;
                    var totalProgress = progress + chunckProgress * p;

                    if (totalProgress > 100) {
                        totalProgress = 100;
                    }

                    if (totalProgress) {
                        totalProgress = totalProgress.toFixed(2);
                    }

                    // console.log( 'totalProgress=', totalProgress, 'progress=', progress, ' chunckProgress=', chunckProgress, ' progressMax=', progressMax)
                    progressCallback(totalProgress);
                });

                xhr.addEventListener("load", function () {

                    var response = {};
                    try {
                        response = JSON.parse(xhr.responseText);
                    } catch (e) {
                        console.log('upload error', e);
                        attachment.remove();
                        failureCallback({ code: 500, message: e.message, extra: { error: e } });
                        return;
                    }

                    // 上传失败
                    if (response.code != 0 || _typeof(response.data) != "object") {
                        var message = response.message || "上传失败";
                        attachment.remove();
                        console.log(message);
                        failureCallback(response);
                        return;
                    }

                    if (response.completed) {
                        var data = response.data || {};
                        // console.log( data );
                        setContent(data);
                        successCallback(data);
                    }

                    sendRequest(next + 1);
                });

                var blob = file.slice(start, end, file.type);
                var formData = new FormData();
                formData.append("file", blob, name);

                xhr.open("POST", url, true);
                xhr.setRequestHeader("Content-Disposition", 'attachment; filename="' + encodeURIComponent(name) + '"');
                xhr.setRequestHeader("Content-Range", 'bytes ' + start + '-' + (end - 1) + '/' + total);
                xhr.send(formData);
            }

            sendRequest(0);
        }

        /**
         * 通过网址抓取附件
         * @param {*} progressCallback 
         * @param {*} successCallback 
         * @param {*} failureCallback 
         */
        function fetchUrl(progressCallback, successCallback, failureCallback) {

            var values = {};
            try {
                values = attachment.attachment.attributes.values;
            } catch (e) {
                failureCallback({ code: 500, message: e.message, extra: { e: e } });
                return;
            }

            var type = values["contentType"];
            if (type != "image") {
                // 忽略其他附件格式
                return;
            }

            // 是否抓取网络图片( 下一版实现 )
            // if ( !attrs["fetch-image"] ) {
            if (true) {
                attachment.file = {
                    name: new Date().getTime() + ".png",
                    size: '100kb'
                };
                var data = {
                    mime: "image/png",
                    url: values["url"],
                    origin: values["url"]
                };

                setContent(data);
                successCallback(data);
                return;
            }
        }

        /**
         * 设定附件内容预览
         * @param {*} data 
         */
        function setContent(data) {

            var file = attachment.file;
            var attributes = data;
            attributes["previewable"] = false;
            attributes["href"] = data.url;

            if (!data.mime) {
                data.mime = "application/file";
            }

            if (data.mime.includes("image")) {
                // 图片
                // attributes["content"] = `
                //     <span class="trix-preview-image" data-url="${data.url}"  data-name="${file.name}" >
                //         <img src="${data.url}" /> 
                //     <span>
                // `;
                attributes["previewable"] = true;
            } else if (data.mime.includes("video")) {
                // 视频
                attributes["content"] = '\n                    <span class="trix-preview-video jm-field-ignore"  data-url="' + data.url + '"  data-name="' + file.name + '" >\n                        <video width="100%" height="auto" controls>\n                            <source src="' + data.url + '" type="' + data.mime + '">\n                        </video>\n                    <span>\n                ';
            } else if (data.mime.includes("audio")) {

                attributes["content"] = '\n                    <span class="trix-preview-audio jm-field-ignore"   data-url="' + data.url + '"  data-name="' + file.name + '" >\n                        <audio controls>\n                            <source src="' + data.url + '" type="' + data.mime + '">\n                        </audio>\n                    <span>\n                ';
            } else {
                var ext = 'unknown';
                if (data.url) {
                    var uri = data.url.split(".");
                    if (uri.slice) {
                        ext = uri.slice(-1).pop();
                    }
                }

                attributes["content"] = '\n                    <span class="trix-preview-file" data-url="' + data.url + '"  data-name="' + file.name + '" >\n                        <span class="icon trix-preview-icon-' + ext + '"></span>\n                        <span class="title"> ' + file.name + ' </span>\n                    <span>\n                ';
            }
            try {
                attachment.setAttributes(attributes);
            } catch (e) {
                console.log('setAttributes Error', e);
            }
        }
    },


    // 添加个性化面板
    addNewBlock: function addNewBlock(trix, name) {
        name = name || "custom";
        var toolBar = trix.toolbarElement;
        var spacer = toolBar.querySelector(".trix-button-group-spacer");
        var blockElm = document.createElement("span");
        blockElm.setAttribute("class", 'trix-button-group trix-button-group--block-tools trix-button-group-' + name);
        blockElm.setAttribute("data-trix-button-group", "block-tools");

        if (spacer) {
            spacer.before(blockElm);
        }
    },

    // 添加分割线
    addDivider: function addDivider(trix) {

        var trixId = trix.trixId;
        var buttonContent = '\n            <button type="button" \n                class="trix-button trix-button--icon trix-button--icon-divider" \n                onclick="\n                    var trix = document.querySelector(\'trix-editor[trix-id=\\\'' + trixId + '\\\']\');\n                    trix.editor.insertHTML(\'<p><hr/></p>\')\n                "\n                data-trix-key="+" title="\u5206\u5272\u7EBF" tabindex="-1"></button>\n        ';

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-text");
        blockElm.insertAdjacentHTML("beforeend", buttonContent);
    },

    // 添加对齐选项
    addAlignments: function addAlignments(trix) {
        var trixId = trix.trixId;
        var alignments = [{ name: "align-left", value: "left", title: "左对齐" }, { name: "align-center", value: "center", title: "居中对齐" }, { name: "align-right", value: "right", title: "右对齐" }, { name: "align-justify", value: "justify", title: "两端对齐" }];
        var buttonContent = '';
        for (var i in alignments) {
            var ali = alignments[i];
            buttonContent += '\n                <button type="button" \n                    onclick="\n                        var trix = document.querySelector(\'trix-editor[trix-id=\\\'' + trixId + '\\\']\');\n                        var dialog = this.parentElement.parentElement.parentElement.parentElement;\n                        trix.editor.deactivateAttribute(\'align-left\');\n                        trix.editor.deactivateAttribute(\'align-center\');\n                        trix.editor.deactivateAttribute(\'align-right\');\n                        trix.editor.deactivateAttribute(\'align-justify\');\n                        trix.editor.activateAttribute(\'' + ali.name + '\');\n                    "\n                    class="trix-button trix-button--icon trix-button--icon-' + ali.name + '" \n                    data-trix-attribute="' + ali.name + '"\n                    data-trix-method="setAttribute" \n                    data-trix-key="+" title="' + ali.title + '" tabindex="-1"></button>\n            ';
        }

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-alignment");
        blockElm.insertAdjacentHTML("beforeend", buttonContent);
    },

    // 添加标题选项
    addHeading: function addHeading(trix) {

        var trixId = trix.trixId;
        var headings = [{ class: "heading-1", name: "一级标题" }, { class: "heading-2", name: "二级标题" }, { class: "heading-3", name: "三级标题" }, { class: "heading-4", name: "四级标题" }, { class: "heading-5", name: "五级标题" }];

        function getHeadingItem(headings) {
            var headingItem = '';
            for (var i in headings) {
                var _h = headings[i];
                var name = "heading-" + (parseInt(i) + 1);
                headingItem += '\n                    <li>\n                        <a  \n                            href="javascript:void(0);"\n                            onclick="\n                                var trix = document.querySelector(\'trix-editor[trix-id=\\\'' + trixId + '\\\']\');\n                                var dialog = this.parentElement.parentElement.parentElement.parentElement;\n                                var selected = dialog.querySelector(\'a[data-trix-active]\');\n                                if ( selected  ){\n                                    var name = selected.getAttribute(\'data-trix-attribute\');\n                                    if ( name != this.getAttribute(\'data-trix-attribute\') ) {\n                                        trix.editor.deactivateAttribute(name);\n                                        trix.editor.activateAttribute(this.getAttribute(\'data-trix-attribute\'));\n                                    }\n                                }\n                            "\n                            class="trix-dialog-heading-item trix-button" \n                            data-trix-attribute="' + name + '" \n                            data-trix-method="setAttribute"\n                        >\n                            <span class="' + _h.class + ' trix-dialog-heading">' + _h.name + '</span>\n                        </a>\n                    </li>\n                ';
            }
            return headingItem;
        }

        var headingItem = getHeadingItem(headings);

        var buttonContent = '\n            <button type="button" \n                class="trix-button trix-button--icon trix-button--icon-heading" \n                data-trix-attribute="heading" \n                data-trix-key="+" title="\u6807\u9898" tabindex="-1"></button>\n        ';

        var dialogContent = '\n            <div class="trix-dialog trix-dialog--heading" data-trix-dialog="heading" data-trix-dialog-attribute="heading"  >\n                <input \n                    type="hidden" name="heading" \n                    data-trix-input required >\n                <ul>\n                    ' + headingItem + '\n                    <li>\n                        <a  href="javascript:void(0);"\n                            class="trix-dialog-heading-item" \n                            onclick="\n                                var trix = document.querySelector(\'trix-editor[trix-id=\\\'' + trixId + '\\\']\');\n                                var dialog = this.parentElement.parentElement.parentElement.parentElement;\n                                var selected = dialog.querySelector(\'a[data-trix-active]\');\n                                if ( selected  ){\n                                    var name = selected.getAttribute(\'data-trix-attribute\');\n                                    trix.editor.deactivateAttribute(name);\n                                }\n                            "\n                            data-trix-method="removeAttribute" \n                        >\n                            <span class="trix-dialog-normal">\u6B63\u6587</span>\n                        </a>\n                    </li>\n                </ul>\n            </div>\n        ';

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-text");
        var dialogElm = toolBar.querySelector(".trix-dialogs");
        blockElm.insertAdjacentHTML("beforeend", buttonContent);
        dialogElm.insertAdjacentHTML("beforeend", dialogContent);
    },

    // 添加颜色选择
    addColor: function addColor(trix) {

        // 色板
        var colors = {
            standard: ["#717071", "#c9c9c9", "#fe8b7b", "#fec470", "#7ed6a6", "#5dc9e8", "#c793e7"],
            theme: ["#333333", "#808080", "#d14b3a", "#d39236", "#45ab73", "#239dc1", "#8f54b5", "#717071", "#c9c9c9", "#fe8b7b", "#fec470", "#7ed6a6", "#5dc9e8", "#c793e7", "#b5b5b5", "#e3e3e3", "#fec3ba", "#fee0b4", "#bcead0", "#abe3f3", "#e1c7f2"]
        };

        function getColorItem(colors) {
            var colorItem = '';
            for (var i in colors) {
                var c = colors[i];
                colorItem += '\n                    <li>\n                        <a  \n                            href="javascript:void(0);"\n                            onclick="\n                                var dialog = this.parentElement.parentElement.parentElement.parentElement;\n                                var color = dialog.querySelector(\'[name=\\\'color\\\']\');\n                                    color.value=\'' + c + '\';\n                            "\n                            class="trix-dialog-color-item" \n                            data-trix-method="setAttribute" \n                        >\n                            <span class="trix-dialog-color" style="background-color:' + c + '"></span>\n                        </a>\n                    </li>\n                ';
            }
            return colorItem;
        }

        var standardColorItem = getColorItem(colors.standard); // 标准色 
        var themeColorItem = getColorItem(colors.theme);; // 主题色

        var trixId = trix.trixId;
        var buttonContent = '\n            <button type="button" \n                class="trix-button trix-button--icon trix-button--icon-color" \n                data-trix-attribute="color" \n                data-trix-key="+" title="\u989C\u8272" tabindex="-1"></button>\n        ';

        var dialogContent = '\n            <div class="trix-dialog trix-dialog--color" data-trix-dialog="color" data-trix-dialog-attribute="color"  >\n                <input \n                    type="hidden" name="color" data-trix-input required >\n\n                <div class="trix-dialog-color-group">\n                    <a href="javascript:void(0);"  \n                        data-trix-method="removeAttribute" \n                        class="trix-dialog-color-block">\n                        <span class="trix-dialog-color trix-dialog-color--default"></span>\n                        \u81EA\u52A8\n                    </a>\n                </div>\n\n                <div class="trix-dialog-color-group">\n                    <div class="trix-dialog-color-group-title">\n                        \u6807\u51C6\u8272\n                    </div>\n                    <ul>\n                        ' + standardColorItem + '\n                    </ul>\n                </div>\n\n                <div class="trix-dialog-color-group">\n                    <div class="trix-dialog-color-group-title">\n                        \u4E3B\u9898\u8272\n                    </div>\n                    <ul>\n                        ' + themeColorItem + '\n                    </ul>\n                </div>\n            </div>\n        ';

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-text");
        var dialogElm = toolBar.querySelector(".trix-dialogs");
        blockElm.insertAdjacentHTML("beforeend", buttonContent);
        dialogElm.insertAdjacentHTML("beforeend", dialogContent);
    },

    // 添加附件 
    addAttach: function addAttach(trix) {

        var trixId = trix.trixId;

        var buttonContent = '\n            <button type="button" \n                class="trix-button trix-button--icon trix-button--icon-attach" \n                data-trix-attribute="attach" \n                data-trix-key="+" title="\u9644\u4EF6" tabindex="-1"></button>\n        ';

        var dialogContent = '\n            <div class="trix-dialog trix-dialog--attach" data-trix-dialog="attach" data-trix-dialog-attribute="attach"  >\n                <div class="trix-dialog__attach-fields">\n                    <input type="file" class="trix-input trix-input--dialog" >\n                    <div class="trix-button-group">\n                        <input type="button" class="trix-button trix-button--dialog" \n                            onclick="\n                                var trix = document.querySelector(\'trix-editor[trix-id=\\\'' + trixId + '\\\']\');\n                                var fileElm = this.parentElement.parentElement.querySelector(\'input[type=\\\'file\\\']\');\n                                if ( fileElm.files.length == 0 ) { \n                                    console.log(\'nothing selected\');\n                                    return;\n                                }\n                                var file = fileElm.files[0];\n                                trix.editor.insertFile(file);\n                            ";\n                            value="\u63D2\u5165\u9644\u4EF6" data-trix-method="removeAttribute"\n                        >\n                        <input type="button" class="trix-button trix-button--dialog" value="\u53D6\u6D88\u64CD\u4F5C" data-trix-method="removeAttribute">\n                    </div>\n                </div> \n            </div>\n        ';

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-custom");
        var dialogElm = toolBar.querySelector(".trix-dialogs");

        blockElm.insertAdjacentHTML("beforeend", buttonContent);
        dialogElm.insertAdjacentHTML("beforeend", dialogContent);
    },

    // 添加图片 (下一版实现 )
    addImage: function addImage(trix) {

        var button = document.createElement("button");
        button.setAttribute("data-trix-action", "x-image");
        button.setAttribute("class", "trix-button trix-button--icon trix-button--icon-image");
        button.setAttribute("type", "button");

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-custom");
        var imageBtn = blockElm.appendChild(button);

        // 上传按钮点击, 选择文件并上传
        imageBtn.addEventListener("click", function () {
            console.log('选择图片并上传');
        });
    },

    // 添加视频 (下一版实现 )
    addVideo: function addVideo(trix) {

        var button = document.createElement("button");
        button.setAttribute("data-trix-action", "x-image");
        button.setAttribute("class", "trix-button trix-button--icon trix-button--icon-video");
        button.setAttribute("type", "button");

        var toolBar = trix.toolbarElement;
        var blockElm = toolBar.querySelector(".trix-button-group-custom");
        var videoBtn = blockElm.appendChild(button);

        // 上传按钮点击, 选择文件并上传
        videoBtn.addEventListener("click", function () {
            console.log('选择视频并上传');
        });
    },

    getAttrs: function getAttrs($elm) {
        var data = {};
        var parseObject = function parseObject(value) {
            var vals = value == null ? '' : value.split(';');
            var len = vals.length;
            var vlist = {};
            for (var i = 0; i < len; i++) {
                var v = vals[i];
                var m = v == null ? [""] : v.split(':');
                if (m.length == 2) {
                    vlist[m[0]] = m[1];
                }
            }
            return vlist;
        };

        $.each(this.props, function (name, type) {

            if (name) {
                name = name.trim();
            }
            if (type) {
                type = type.trim();
            }

            switch (type) {
                case 'string':
                    data[name] = $elm.attr(name) || null;
                    break;
                case 'bool':
                    data[name] = $elm.attr(name) !== undefined && $elm.attr(name) !== "false" && $elm.attr(name) !== "0";
                    break;
                case 'object':
                    data[name] = parseObject($elm.attr(name));
                    break;
                case 'array':
                    var src = $elm.attr(name) || "";
                    data[name] = src.split(',');
                    break;
                case 'number':
                    data[name] = $elm.attr(name) ? parseInt($elm.attr(name)) : null;
                    break;
                case 'json':
                    var json = null;
                    if ($elm.attr(name)) {
                        try {
                            json = JSON.parse($elm.attr(name));
                        } catch (e) {
                            console.log('json parser error:', $elm.attr('name'), name, $elm.attr(name), e);
                        }
                    }
                    data[name] = json;
                    data['__json__' + name] = $elm.attr(name); // 留存原始数据
                    break;
                case 'function':
                    var evt = function evt() {};
                    if ($elm.attr(name)) {
                        var exp = "evt=" + $elm.attr(name);
                        try {
                            eval(exp);
                        } catch (e) {
                            console.log('function error:', $elm.attr('name'), name, exp, e);
                        }
                    }
                    data[name] = evt;
                    break;
                default:
                    data[name] = $elm.attr(name);
            }
        });
        return data;
    }
});

module.exports = com;

},{}],3:[function(require,module,exports){
"use strict";

var com = Page({
	data: {},
	template: '<div>图片编辑组件</div>',
	events: {},
	cropper: null,
	props: {
		"disabled": "bool", // 是否 disabled
		"name": "string", // 名称
		"id": "string", // ID
		"url": "string", // 云端通信地址
		"value": "json", // 数值
		"crop": "object", // 裁切配置
		"tools": "array" // 工具
	},
	onReady: function onReady(params) {
		var _this = this;

		var $elms = $(params['selector']);
		this.template = $('component[name=editor-image]').html().toString();
		this.events.change = typeof params['change'] == 'function' ? params['change'] : function () {};
		this.events.error = typeof params['error'] == 'function' ? params['error'] : function () {};
		this.events.success = typeof params['success'] == 'function' ? params['success'] : function () {};

		$elms.each(function (idx, elm) {
			_this.init($(elm));
		});
	},

	init: function init($elm) {
		var attrs = this.getAttrs($elm);
		var html = Mustache.render(this.template, attrs);
		$elm.html(html);
		$elm.addClass('editor-inited'); //标记初始化完毕
		this.setAttrs($elm, attrs);

		// 自动按比例裁切
		var aspectRatio = NaN;
		var autoCrop = false;
		var dragMode = 'none';

		if (attrs['crop']['ratio']) {
			autoCrop = true;
			dragMode = 'crop';
			try {
				eval('aspectRatio=' + attrs['crop']['ratio']);
			} catch (e) {
				aspectRatio = NaN;
			}
		}

		// 固定比例裁切
		if (aspectRatio) {
			$elm.find('.croped').remove();
		}

		// 图片对象
		var $img = $elm.find('.origin-image');

		//fix preview bug
		$img.load(function (event) {
			$img.data('img-width', $img.width());
			$img.data('img-height', $img.height());
		});

		// 载入画布和图像
		$img.cropper({
			dragMode: dragMode,
			aspectRatio: aspectRatio,
			autoCrop: autoCrop, // 自动裁切
			preview: '[name="' + attrs['name'] + '-preview"]',
			ready: function ready(event) {
				$img.cropper('zoom', -0.1);

				// const containerData = $img.cropper('getContainerData');
				// $img.cropper('zoomTo', containerData.width/ containerData.height, { x: 0,y: 0 });
			},
			crop: function crop(event) {

				var w = event.detail.width || $img.data('img-width');
				var h = event.detail.height || $img.data('img-height');
				var ratio = w / h;
				$elm.find('.width-preview').html(w.toFixed(0));
				$elm.find('.height-preview').html(h.toFixed(0));
				$elm.find('.ratio-preview').html(ratio.toFixed(2));
			}
		});

		// 留存原始数据
		$elm.data('origin-value', attrs['value']);

		// 初始化工具条
		this.initToolbar($elm);
	},

	/**
  * 初始化工具条
  * @param  {[type]} $elm [description]
  * @return 
  */
	initToolbar: function initToolbar($elm) {
		var _this2 = this;

		// 裁切
		$elm.find('.crop').click(function (event) {
			var $elm = $(this).parents('.jm-editor-image');
			var $img = $elm.find('.origin-image');
			$img.cropper('setDragMode', 'crop');
			$elm.find('.croped').removeClass('uk-hidden');
		});

		// 移动
		$elm.find('.move').click(function (event) {
			var $elm = $(this).parents('.jm-editor-image');
			var $img = $elm.find('.origin-image');
			$img.cropper('setDragMode', 'move');
			$elm.find('.croped').removeClass('uk-hidden');
		});

		// 放大
		$elm.find('.zoomin').click(function (event) {
			var $elm = $(this).parents('.jm-editor-image');
			var $img = $elm.find('.origin-image');
			$img.cropper('zoom', +0.1);
		});

		// 缩小
		$elm.find('.zoomout').click(function (event) {
			var $elm = $(this).parents('.jm-editor-image');
			var $img = $elm.find('.origin-image');
			$img.cropper('zoom', -0.1);
		});

		// 设定比例
		$elm.find('.aspectratio').click(function (event) {
			var $elm = $(this).parents('.jm-editor-image');
			var $img = $elm.find('.origin-image');
			var ratiostr = $(this).attr('data-value');
			var ratio = NaN;
			try {
				eval('ratio=' + ratiostr);
			} catch (e) {
				ratio = NaN;
			}
			$img.cropper('setAspectRatio', ratio);
		});

		// 重置
		$elm.find('.reset').click(function () {
			_this2.reset($elm);
		});

		// 保存
		$elm.find('.save').click(function () {
			_this2.save($elm);
		});
	},

	/**
  * 恢复到初始化的状态
  * @param  {[type]} $elm [description]
  * @return {[type]}      [description]
  */
	reset: function reset($elm) {

		var $img = $elm.find('.origin-image');
		var val = $elm.data('origin-value') || {};

		// Reset 控件
		$img.cropper('reset');
		$img.cropper('zoom', -0.1);

		// Reset value
		$elm.find('[name=title]').val(val.title || '');
		$elm.find('[name=link]').val(val.link || '');
		$elm.find('[name=summary]').val(val.summary || '');
		$elm.attr('value', JSON.stringify(val));

		// 隐藏提醒窗体
		$elm.find('.reset-drop').each(function (idx, el) {
			UIkit.drop($(el)).hide();
		});
	},

	/**
  * 保存
  * @return {[type]} [description]
  */
	save: function save($elm) {
		var _this3 = this;

		var url = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;


		var $img = $elm.find('.origin-image');
		var attrs = this.getAttrs($elm);
		var value = attrs['value'];
		url = url ? url : attrs['url'];

		value['title'] = $elm.find('[name=title]').val() || "";
		value['link'] = $elm.find('[name=link]').val() || "";
		value['summary'] = $elm.find('[name=summary]').val() || "";
		$elm.attr('value', JSON.stringify(value));

		var croped = $img.cropper('getData');
		if (url) {
			this.lock($elm);
			$.post(url, { 'crop': JSON.stringify(croped), 'value': $elm.attr('value') }, function (data, status, xhr) {
				_this3.unlock($elm);

				if (typeof data['code'] != 'undefined' && data['code'] != 0) {
					_this3.error($elm, data, xhr);
					return;
				}

				_this3.success($elm, data, xhr);
			}, 'json');
		}
	},

	/**
  * 错误通报
  * @param  {[type]} $elm [description]
  * @return {[type]}      [description]
  */
	error: function error($elm, data, xhr) {
		try {
			this.events.error(this, data, $elm);
		} catch (e) {
			console.log('Events error call fail', e);
		}
	},

	/**
  * 成功返回
  * @param  {[type]} $elm [description]
  * @param  {[type]} data [description]
  * @param  {[type]} xhr  [description]
  * @return {[type]}      [description]
  */
	success: function success($elm, data, xhr) {

		if (typeof data['value'] != 'undefined') {
			$elm.attr('value', JSON.stringify(data['value']));
		}

		try {
			this.events.success(this, data, $elm);
		} catch (e) {
			console.log('Events success call fail', e);
		}
	},

	/**
  * 锁定操作界面
  * @param  {[type]} $elm [description]
  * @return {[type]}      [description]
  */
	lock: function lock($elm) {

		$elm.find('a').addClass('uk-disabled');
		$elm.find('a').prop('disabled', true);

		$elm.find('input').addClass('uk-disabled');
		$elm.find('input').prop('disabled', true);

		$elm.find('textarea').addClass('uk-disabled');
		$elm.find('textarea').prop('disabled', true);

		$elm.find('button').addClass('uk-disabled');
		$elm.find('button').prop('disabled', true);
	},

	/**
  * 解锁操作界面
  * @param  {[type]} $elm [description]
  * @return {[type]}      [description]
  */
	unlock: function unlock($elm) {

		$elm.find('a').removeClass('uk-disabled');
		$elm.find('a').prop('disabled', false);

		$elm.find('input').removeClass('uk-disabled');
		$elm.find('input').prop('disabled', false);

		$elm.find('textarea').removeClass('uk-disabled');
		$elm.find('textarea').prop('disabled', false);

		$elm.find('button').removeClass('uk-disabled');
		$elm.find('button').prop('disabled', false);
	},

	setAttrs: function setAttrs($elm, attrs) {
		// console.log( attrs );
	},

	getAttrs: function getAttrs($elm) {
		var data = {};
		var parseObject = function parseObject(value) {
			var vals = value == null ? '' : value.split(';');
			var len = vals.length;
			var vlist = {};
			for (var i = 0; i < len; i++) {
				var v = vals[i];
				var m = v == null ? [""] : v.split(':');
				if (m.length == 2) {
					vlist[m[0]] = m[1];
				}
			}
			return vlist;
		};

		$.each(this.props, function (name, type) {
			switch (type) {
				case 'string':
					data[name] = $elm.attr(name) || null;
					break;
				case 'bool':
					data[name] = $elm.attr(name) ? true : false;
					break;
				case 'object':
					data[name] = parseObject($elm.attr(name));
					break;
				case 'array':
					var src = $elm.attr(name) || "";
					data[name] = src.split(',');
					break;
				case 'number':
					data[name] = $elm.attr(name) ? parseInt($elm.attr(name)) : null;
					break;
				case 'json':
					var json = null;
					if ($elm.attr(name)) {
						try {
							json = JSON.parse($elm.attr(name));
						} catch (e) {
							console.log('json parser error:', $elm.attr('name'), name, $elm.attr(name), e);
						}
					}
					data[name] = json;
					data['__json__' + name] = $elm.attr(name); // 留存原始数据
					break;
				default:
					data[name] = $elm.attr(name);
			}
		});
		return data;
	}
});

module.exports = com;

},{}],4:[function(require,module,exports){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var com = Page({
	_name: 'ImageUploader',
	data: {},
	template: '<div>图片上传组件</div>',
	events: {},
	props: {
		"multiple": "bool", // 是否支持上传多张图片
		"disabled": "bool", // 是否 disabled
		"name": "string", // 名称
		"id": "string", // ID
		"url": "string", // 上传API云端地址
		"crop": "object", // 裁切配置
		"type": "string", // 类型 
		"class": "string", // 特别类型
		"ratio": "string", // 图片比例 eg: 16/9  auto 
		"allow": "string", // 文件类型校验正则 /(\.|\/)(gif|jpe?g|png|xls|xlsx|ai)$/i
		"accept": "string", // 许可文件类型 .jpg,.png 
		"maxFileSize": "number", // 文件最大值, 默认 2G 单位 kb 
		"maxChunkSize": "number", // 分段上传每次上传最大字节单位: kb
		"value": "json", // 数值
		"thumb": "string", // 缩略图字段, 默认为 url
		"validate": "string", // 验证信息
		"title": "string", // 标题字段，默认为 title
		"titleClass": "string", //标题栏样式
		"titleStyle": "string" //标题栏样式
	},

	onReady: function onReady(params) {
		var _this = this;

		var $elms = $(params['selector']);
		this.template = $('component[name=uploader-image]').html().toString();
		this.events.add = typeof params['add'] == 'function' ? params['add'] : function () {};
		this.events.beforeupload = typeof params['beforeupload'] == 'function' ? params['beforeupload'] : function () {};
		this.events.uploaded = typeof params['uploaded'] == 'function' ? params['uploaded'] : function () {};
		this.events.error = typeof params['error'] == 'function' ? params['error'] : function () {};
		this.events.change = typeof params['change'] == 'function' ? params['change'] : function () {};

		this.events.success = typeof params['success'] == 'function' ? params['success'] : function () {};

		$elms.each(function (idx, elm) {
			_this.init($(elm));
		});

		$(document).on('dragover', function () {
			$('.jm-uploader-image').addClass('jm-prepare');
		});

		$(document).on('drop dragleave mouseleave keyup', function () {
			$('.jm-uploader-image').removeClass('jm-prepare');
		});

		$(document).on('keydown', function (e) {
			var keyCode = e.keyCode;
			if (keyCode == 91 || keyCode == 17) {
				$('.jm-uploader-image').addClass('jm-prepare');
			}
		});
	},

	/**
  * API Method
  * @return {[type]} [description]
  */
	val: function val() {
		return this.getValue($(this.selector));
	},

	getValue: function getValue($elm) {
		var value = $elm.find('input[type=hidden]').val();
		try {
			value = JSON.parse(value);
		} catch (e) {
			value = {};
		};

		return value;
	},

	initValue: function initValue($elm, value, attrs) {
		if (!$.isArray(value)) {
			value = [value];
		}
		for (var i in value) {
			if (value != "" && value != null) {
				var v = value[i];
				this.add($elm, v, attrs);
			}
		}
	},

	setValue: function setValue($item, value, attrs) {

		var thumbField = attrs['thumb'] ? attrs['thumb'] : 'url';
		var titleField = attrs['title'] ? attrs['title'] : 'title';
		var thumb = (typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object' && value != null ? value[thumbField] : value;
		var title = (typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object' && value != null ? value[titleField] : "";
		$item.find('img').attr('src', thumb);
		title != "" ? $item.find('.title').removeClass('uk-hidden').html(title) : $item.find('.title').addClass('uk-hidden');
		$item.data('value', value);

		// 更新数据
		var $elm = $item.parents('uploader');
		this.updateValue($elm, attrs['multiple']);
	},

	updateValue: function updateValue($elm, multiple) {

		var values = [];
		$elm.find('.item:not(.uk-hidden)').each(function (index, it) {
			values.push($(it).data('value'));
		});

		if (values.length == 0) {
			$elm.find('input[type=hidden]').val('');
			return true;
		}

		if (!multiple) {
			$elm.find('input[type=hidden]').val(JSON.stringify(values[0]));
			return true;
		}

		$elm.find('input[type=hidden]').val(JSON.stringify(values));
		return true;
	},

	setAttrs: function setAttrs($elm, attrs) {
		var _this2 = this;

		// 设定多图上传
		$elm.find('input[type="file"]').prop('multiple', attrs['multiple']); // 多图上传

		if (attrs['ratio'] != null && attrs['ratio'] != 'auto') {
			var ratio = null;
			try {
				ratio = eval(attrs['ratio']);
			} catch (e) {
				ratio = null;console.log(attrs['name'], ' ratio error:', attrs['ratio']);
			};
			this.setRatio($elm.find('.item'), ratio);
		}

		// 初始化数值
		this.initValue($elm, attrs['value'], attrs);

		// 设定添加按钮
		var cnt = $elm.find('.item:not(.uk-hidden)').length;
		if (cnt >= 1 && !attrs['multiple']) {
			this.hideUploadBtn($elm);
		}

		// disabled
		if (attrs['disabled']) {
			this.disabled($elm);
		}

		// 允许文件类型
		var acceptFileTypes = /^.*$/i;
		if (attrs['allow']) {
			try {
				acceptFileTypes = eval(attrs['allow']);
			} catch (e) {
				console.log('allow does not correct', e);
			}

			if (typeof acceptFileTypes.test != 'function') {
				acceptFileTypes = /^.*$/i;
			}
		}

		// 允许文件大小
		var maxFileSize = attrs['maxFileSize'] ? attrs['maxFileSize'] * 1024 : 2147483648; // 2GB
		var maxChunkSize = attrs['maxChunkSize'] ? attrs['maxChunkSize'] * 1024 : undefined; // 不分段

		// 允许
		// 初始化 upload 控件
		// @see https://github.com/blueimp/jQuery-File-Upload/wiki/Options
		$elm.find('input[type=file]').fileupload({
			dropZone: $elm,
			pasteZone: $elm,
			url: attrs['url'] ? attrs['url'] : $elm.parent('form').attr('action'),
			dataType: 'json',
			type: 'POST',
			maxChunkSize: maxChunkSize,
			recalculateProgress: false,
			formData: {},
			add: function add(e, data) {

				// trigger add event
				var eventResp = true;
				try {
					eventResp = _this2.events.add(e, data);
				} catch (e) {
					console.log('trigger add event error', e);
				}
				if (eventResp == false) {
					return;
				}

				// disabled
				if ($elm.prop('disabled')) {
					_this2.disabled($elm);
					return;
				}

				var $item = _this2.add($elm, null, attrs, true); // 添加 item
				var errors = [];

				// 校验filetype
				if (data.originalFiles[0]['type'].length && !acceptFileTypes.test(data.originalFiles[0]['type']) && !acceptFileTypes.test(data.originalFiles[0]['name'])) {
					errors.push({
						code: 403,
						message: '文件类型不允许上传',
						extra: {
							filename: data.originalFiles[0]['name'],
							filetype: data.originalFiles[0]['type'],
							acceptFileTypes: acceptFileTypes,
							accept: attrs['accept']
						}
					});
				}

				if (data.originalFiles[0]['size'] && data.originalFiles[0]['size'] > maxFileSize) {
					errors.push({
						code: 403,
						message: '文件大小不能超过' + maxFileSize / 1024 / 1024 + 'M',
						extra: {
							maxFileSize: maxFileSize,
							filesize: data.originalFiles[0]['size'],
							filename: data.originalFiles[0]['name'],
							filetype: data.originalFiles[0]['type']
						}
					});
				}

				if (errors.length > 0) {
					_this2.error($item, errors, attrs);
					return;
				}

				if (!$item) {
					errors.push({
						code: 402,
						message: '添加失败, 每次最多添加一个文件',
						extra: {
							maxFileSize: maxFileSize,
							filesize: data.originalFiles[0]['size'],
							filename: data.originalFiles[0]['name'],
							filetype: data.originalFiles[0]['type']
						}
					});

					_this2.error($item, errors, attrs);
					return;
				}

				data['$item'] = $item;
				$item.find('.name').removeClass('uk-hidden');
				$item.find('.name').html(data.files[0].name);

				// trigger beforeupload event
				eventResp = true;
				try {
					eventResp = _this2.events.beforeupload(e, data);
				} catch (e) {
					console.log('trigger beforeupload event error', e);
				}
				if (eventResp == false) {
					// 恢复状态
					_this2.remove($item, attrs);
					return;
				}

				data.submit();
			},
			progress: function progress(e, data) {
				// let progress = parseInt(data.loaded / data.total * 100, 10);
				var $p = data.$item.find('progress');
				$p.attr('max', data.total);
				$p.attr('value', data.loaded);
				// console.log( $p );
			},
			always: function always(e, data) {
				// donoting
			},
			fail: function fail(e, data) {
				_this2.error(data.$item, [result], attrs);
			},
			done: function done(e, data) {

				var result = data.result;
				if (result.code != 0) {
					_this2.error(data.$item, [result], attrs);
					return;
				}
				// Success
				_this2.uploaded(data.$item, result.data, attrs);
			}
		});

		// 初始化排序控件
		UIkit.util.on($elm, 'moved', function (event) {
			_this2.updateValue($elm, attrs['multiple']);
		});
	},

	init: function init($elm) {

		var attrs = this.getAttrs($elm);
		attrs['_html'] = $elm.html();

		// 默认值
		if (attrs['titleClass'] == '' || attrs['titleClass'] == null) {
			attrs['titleClass'] = 'uk-overlay-default uk-position-bottom';
		}

		if (attrs['validate'] == '' || attrs['validate'] == null) {
			attrs['validate'] = '{}';
		}

		var html = Mustache.render(this.template, attrs);
		$elm.html(html);
		$elm.addClass('uploader-inited'); //标记初始化完毕

		// 设定参数
		this.setAttrs($elm, attrs);

		// 拖拽事件设定 dragover dragenter drop
		$elm.on('dragover', function () {
			$elm.find('.jm-uploader-image').addClass('jm-active');
		});
		$elm.on('drop dragleave mouseleave', function () {
			$elm.find('.jm-uploader-image').removeClass('jm-active');
		});

		// 关闭提示
		// setTimeout(()=>{$elm.find('.tips').fadeOut(); }, 3000);
	},

	reset: function reset($elm) {
		$elm.html('');
	},

	bindItemEvents: function bindItemEvents($item, attrs) {
		var _this3 = this;

		// 删除时候触发
		$item.find('.btn-remove').click(function (event) {
			_this3.remove($item, attrs);
		});

		// ratio auto
		if (attrs['ratio'] == 'auto') {
			$item.find('img').load(function (img) {
				var w = $(event.currentTarget).width();
				var h = $(event.currentTarget).height();
				var ratio = w / h;
				_this3.setRatio($item, ratio);
			});
		}
	},

	setRatio: function setRatio($item, ratio) {
		if (typeof ratio == 'number' && ratio != Infinity && ratio > 0) {
			var width = $item.find('.uk-cover-container').width();
			var height = width / ratio;
			$item.height(height);
			$item.find('.uk-cover-container').height(height);
		}
	},

	hideUploadBtn: function hideUploadBtn($elm) {
		$elm.find('.btn-upload').addClass('uk-hidden');
	},

	showUploadBtn: function showUploadBtn($elm) {
		$elm.find('.btn-upload').removeClass('uk-hidden');
	},

	disabled: function disabled($elm) {

		if ($elm == undefined) {
			$elm = $(this.selector);
		}

		$elm.find('.jm-uploader-image').addClass('jm-disabled');
		$elm.find('input[type=file]').prop('disabled', true);
		$elm.find('.item').addClass('uk-disabled');
	},

	enabled: function enabled($elm) {

		if ($elm == undefined) {
			$elm = $(this.selector);
		}

		$elm.find('.jm-uploader-image').removeClass('jm-disabled');
		$elm.find('input[type=file]').prop('disabled', false);
		$elm.find('.item').removeClass('uk-disabled');
	},

	add: function add($elm, value, attrs) {
		var empty = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;


		var cnt = $elm.find('.item:not(.uk-hidden)').length;
		if (cnt >= 1 && !attrs['multiple']) {
			return false;
		}

		var $item = $elm.find('.item:last').clone();
		$item.removeClass('uk-hidden');
		if (empty) {
			this.loading($item);
		}

		$elm.find('.item:last').after($item);
		if (cnt == 0 && !attrs['multiple']) {
			this.hideUploadBtn($elm);
		}

		this.bindItemEvents($item, attrs);
		this.setValue($item, value, attrs);
		return $item;
	},

	remove: function remove($item, attrs) {

		// 记录删除的 $item (表单提交时候一起提交)
		var $elm = $item.parents('uploader');
		var cnt = $elm.find('.item:not(.uk-hidden)').length;
		if (cnt == 1 && !attrs['multiple']) {
			this.showUploadBtn($elm);
		}

		$item.remove();

		// 更新数值
		this.updateValue($elm, attrs['multiple']);
	},

	loading: function loading($item) {
		$item.removeClass('uk-hidden');
		$item.find('progress').prop('hidden', false);
		$item.find('.name').removeClass('uk-hidden');
		$item.find('.uk-overlay-primary').addClass('uk-hidden');
		try {
			this.events.change(null, $item);
		} catch (e) {
			console.log('Events change call fail', e);
		}
	},

	uploaded: function uploaded($item, value, attrs) {
		var $elm = $item.parents('uploader');
		this.setValue($item, value, attrs);

		$item.find('progress').attr('value', 0);
		$item.find('progress').prop('hidden', true);
		$item.find('.name').addClass('uk-hidden');
		$item.find('.uk-overlay-primary').removeClass('uk-hidden');
		$elm.find('.jm-uploader-image').removeClass('jm-error');
		$elm.find('.jm-helper').removeClass('uk-form-danger');

		try {
			this.events.uploaded(value, $item);
		} catch (e) {
			console.log('Events uploaded call fail', e);
		}
		try {
			this.events.change(value, $item);
		} catch (e) {
			console.log('Events change call fail', e);
		}
	},

	error: function error($item, errors, attrs) {

		var $elm = $item.parents('uploader');
		$elm.find('.jm-uploader-image').addClass('jm-error');
		for (var i in errors) {
			var error = errors[i];
			$elm.find('.jm-helper').addClass('uk-form-danger');
			$elm.find('.jm-helper').html(error.message);
		}

		this.remove($item, attrs);
		try {
			this.events.error(errors, $elm);
		} catch (e) {
			console.log('Events error call fail', e);
		}
		try {
			this.events.change(errors, $elm);
		} catch (e) {
			console.log('Events change call fail', e);
		}
	},

	getAttrs: function getAttrs($elm) {
		var data = {};
		var parseObject = function parseObject(value) {
			var vals = value == null ? '' : value.split(';');
			var len = vals.length;
			var vlist = {};
			for (var i = 0; i < len; i++) {
				var v = vals[i];
				var m = v == null ? [""] : v.split(':');
				if (m.length == 2) {
					vlist[m[0]] = m[1];
				}
			}
			return vlist;
		};

		$.each(this.props, function (name, type) {
			switch (type) {
				case 'string':
					data[name] = $elm.attr(name) || null;
					break;
				case 'bool':
					data[name] = $elm.attr(name) ? true : false;
					break;
				case 'object':
					data[name] = parseObject($elm.attr(name));
					break;
				case 'array':
					var src = $elm.attr(name) || "";
					data[name] = src.split(',');
					break;
				case 'number':
					data[name] = $elm.attr(name) ? parseInt($elm.attr(name)) : null;
					break;
				case 'json':
					var json = null;
					if ($elm.attr(name)) {
						try {
							json = JSON.parse($elm.attr(name));
						} catch (e) {
							console.log('json parser error:', $elm.attr('name'), name, $elm.attr(name), e);
						}
					}
					data[name] = json;
					data['__json__' + name] = $elm.attr(name); // 留存原始数据
					break;
				default:
					data[name] = $elm.attr(name);
			}
		});
		return data;
	}
});

module.exports = com;

},{}],5:[function(require,module,exports){
'use strict';

var _component = require('../../../libs/component');

_component.$$.import('editor/image', 'editor/html');

var web = getWeb();

Page({
      data: {},
      current_page_ranked: 1,
      current_page_recommend: 1,
      has_load_all: false,
      current_type: 'ranked',
      loadEditor: function loadEditor() {
            try {
                  // HtmlEditor
                  (0, _component.$$)('editor[type=html]').HtmlEditor({});
            } catch (e) {
                  console.log('Error @HtmlEditor', e);
            }
      },
      onReady: function onReady() {
            var _that = this;

            _that.loadEditor();
            _that.hoverVideoItem();
            _that.handleClickAsk();
            _that.handleClickHideAsk();
            _that.handleClickAddTags();
            _that.handleUnfocusTagsInput();
            _that.handleKeydownTagsInput();
            _that.handleClickBtnDeleteTag();
            _that.handleClickPublish();
            _that.handleClickLoadmore();
            _that.handleClickToggleTab();
      },
      hoverVideoItem: function hoverVideoItem() {
            $('.video_item').hover(function () {
                  $(this).find('.mask').removeClass('none');
            }, function () {
                  $(this).find('.mask').addClass('none');
            });
      },
      showAskModal: function showAskModal() {
            $('.ask_wrap').fadeIn().css({
                  'display': 'flex',
                  'justify-content': 'center',
                  'align-items': 'center'
            });
            $('body').css('overflow', 'hidden');
      },
      hideAskModal: function hideAskModal() {
            $('.ask_wrap').fadeOut();
            $('body').css('overflow', 'auto');
      },
      handleClickAsk: function handleClickAsk() {
            var _that = this;

            $('.ask,.btn_question').on('click', function () {
                  _that.showAskModal();
            });
      },
      handleClickHideAsk: function handleClickHideAsk() {
            var _that = this;

            $('.btn_delete_modal').on('click', function () {
                  _that.hideAskModal();
            });
      },
      handleClickAddTags: function handleClickAddTags() {
            $('.add_topic_wrap').on('click', function () {
                  $(this).hide();
                  $('.topic_text').val('');
                  $('.topic_text_wrap').css('display', 'flex');
            });
      },
      handleUnfocusTagsInput: function handleUnfocusTagsInput() {
            $('.topic_text').blur(function () {
                  $(this).parent().hide();

                  var tagsNum = $('.topic_items').children('.topic_item').length;

                  if (tagsNum < 5) {
                        $('.add_topic_wrap').show();
                  }
            });
      },
      handleKeydownTagsInput: function handleKeydownTagsInput() {
            $('.topic_text').keydown(function (e) {
                  if ($(this).val() && e.which === 13) {
                        $('.topic_items').css('display', 'flex');

                        var tagNodes = '\n                              <div class="topic_item uk-flex uk-flex-middle">\n                                    <a class="topic_item_text">' + $(this).val() + '</a>\n                                    <span class="btn_delete"></span>\n                              </div>\n                        ';
                        $('.topic_items').append(tagNodes);

                        var tagsNum = $('.topic_items').children('.topic_item').length;
                        $('.topic_text_wrap').hide();
                        $('.btn_add_topic').text('\u6DFB\u52A0\u8BDD\u9898 (' + tagsNum + '/5)');
                        if (tagsNum < 5) {
                              $('.add_topic_wrap').show();
                        }

                        return false;
                  }
            });
      },
      handleClickBtnDeleteTag: function handleClickBtnDeleteTag() {
            $('.topic_items').on('click', '.btn_delete', function (e) {
                  $(this).parent().remove();

                  var tagsNum = $('.topic_items').children('.topic_item').length;
                  $('.btn_add_topic').text('\u6DFB\u52A0\u8BDD\u9898 (' + tagsNum + '/5)');

                  if (tagsNum < 5) {
                        $('.add_topic_wrap').show();
                        if (tagsNum === 0) {
                              $('.topic_items').hide();
                        }
                  }
            });
      },
      submitAskForm: function submitAskForm() {
            var tags = '';
            var tags_array = [];

            for (var i = 0; i < $('.topic_item_text').length; i++) {
                  tags_array[i] = $('.topic_item_text').eq(i).text();
            }

            tags = tags_array.join();

            var ask_form_data = tags ? $('#ask_form').serialize() + '&tags=' + tags : '' + $('#ask_form').serialize();
            $.ajax({
                  type: "post",
                  url: "/_api/xpmsns/qanda/question/create",
                  dataType: "json",
                  data: ask_form_data,
                  success: function success(response) {
                        if (response._id) {
                              UIkit.notification({
                                    message: '提问成功',
                                    status: 'success',
                                    pos: 'bottom-right'
                              });

                              setTimeout(function () {
                                    window.location.href = '/qanda/detail/' + response.question_id;
                              }, 300);
                        } else {
                              UIkit.notification({
                                    message: response.message,
                                    status: 'danger',
                                    pos: 'bottom-right'
                              });
                        }
                  },
                  error: function error(err) {
                        console.log(err);
                  }
            });
      },
      handleClickPublish: function handleClickPublish() {
            var _that = this;

            var isValidated = false;

            $('.btn_publish').on('click', function () {

                  if ($('.question_title').val()) {
                        isValidated = true;
                  } else {
                        UIkit.notification({
                              message: '请输入问题标题',
                              status: 'warning',
                              pos: 'bottom-right'
                        });
                  }

                  if (isValidated) {
                        _that.submitAskForm();
                  }
            });
      },
      handleClickToggleTab: function handleClickToggleTab() {
            var _that = this;

            $('.btn_toggle').on('click', function () {
                  function reset() {
                        $('.btn_toggle').removeClass('active');
                        $('.question_content').hide();
                        _that.has_load_all = false;
                  }

                  switch ($(this).data('type')) {
                        case 'recommend':
                              reset();
                              _that.current_type = 'recommend';
                              $('.questions_recommend').show();
                              $(this).addClass('active');
                              break;
                        case 'ranked':
                              reset();
                              _that.current_type = 'ranked';
                              $('.questions_ranked').show();
                              $(this).addClass('active');
                              break;
                  }
            });
      },
      loadMoreQuestions: function loadMoreQuestions() {
            var _that = this;

            function updateQuestionItems(data) {
                  for (var i = 0; i < data.length; i++) {
                        var user_nickname = data[i].user_nickname ? data[i].user_nickname : data[i].user_mobile;
                        var answer_cnt = data[i].answer_cnt ? data[i].answer_cnt : '0';
                        var tags = '';

                        if (data[i].tags) {
                              for (var j = 0; j < data[i].tags.length; j++) {
                                    var tag_nodes = '\n                                          <a\n                                                class="tags cursor_point"\n                                                href="/qanda/tag/' + data[i].tags[j] + '"\n                                          >' + data[i].tags[j] + '</a>\n                                    ';

                                    tags = tags + tag_nodes;
                              }
                        } else {
                              tags = '';
                        }

                        var nodes = '\n                              <div\n                                    class="question_item w_100 flex justify_between align_center"\n                              >\n                                    <div class="left">\n                                          <a\n                                                class="question box_vertical line_clamp_2 overflow_hidden color_333 fontsize_16 cursor_point"\n                                                href="/qanda/detail/' + data[i].question_id + '"\n                                          >' + data[i].title + '</a>\n                                          <div class="publish_info flex fontsize_12 mt_20">\n                                                <span class="publisher">' + user_nickname + '</span>\n                                                <span class="publish_time">' + data[i].publish_time + '</span>\n                                                <div class="tags_wrap">' + tags + '</div>\n                                          </div>\n                                    </div>\n                                    <div class="right flex">\n                                          <div class="option_item flex flex_column align_center justify_between">\n                                                <span class="value font_bold">' + answer_cnt + '</span>\n                                                <span class="name fontsize_14">\u56DE\u7B54</span>\n                                          </div>\n                                    </div>\n                              </div>\n                        ';

                        if (_that.current_type === 'ranked') {
                              $('.questions_ranked').append(nodes);
                        } else {
                              $('.questions_recommend').append(nodes);
                        }
                  }
            }

            if (_that.current_type === 'ranked') {
                  $.ajax({
                        type: "post",
                        url: "/_api/xpmsns/qanda/question/search",
                        dataType: "json",
                        data: {
                              page: _that.current_page_ranked + 1,
                              perpage: "12",
                              select: "question_id,question.title,question.summary,question.content,question.answer_cnt,question.publish_time,user.nickname,user.mobile,category.name,tags,user.user_id",
                              publish_desc: "1"
                        },
                        success: function success(response) {
                              if (response.data.length !== 0) {
                                    updateQuestionItems(response.data);
                                    _that.current_page_ranked = _that.current_page_ranked + 1;
                              } else {
                                    _that.has_load_all = true;

                                    UIkit.notification({
                                          message: '没有更多了',
                                          status: 'danger',
                                          pos: 'bottom-right'
                                    });
                              }
                        },
                        error: function error(err) {
                              console.log(err);
                        }
                  });
            } else {
                  $.ajax({
                        type: "post",
                        url: "/_api/xpmsns/pages/recommend/getContents",
                        dataType: "json",
                        data: {
                              page: _that.current_page_recommend + 1,
                              perpage: "12",
                              slugs: "qanda_recommend",
                              select: "question_id,question.title,question.summary,question.content,question.answer_cnt,question.publish_time,user.nickname,user.mobile,category.name,tags,user.user_id"
                        },
                        success: function success(response) {
                              if (response.data.length !== 0) {
                                    updateQuestionItems(response.data);
                                    _that.current_page_recommend = _that.current_page_recommend + 1;
                              } else {
                                    _that.has_load_all = true;

                                    UIkit.notification({
                                          message: '没有更多了',
                                          status: 'danger',
                                          pos: 'bottom-right'
                                    });
                              }
                        },
                        error: function error(err) {
                              console.log(err);
                        }
                  });
            }
      },
      handleClickLoadmore: function handleClickLoadmore() {
            var _that = this;

            $('.btn_showmore').on('click', function () {
                  if (!_that.has_load_all) {
                        _that.loadMoreQuestions();
                  }
            });
      }
});

},{"../../../libs/component":1}]},{},[5]);
